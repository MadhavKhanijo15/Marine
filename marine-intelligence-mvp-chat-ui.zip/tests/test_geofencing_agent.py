import pytest
from pydantic import ValidationError

from app.agents.geofencing import GeofencingAgent
from app.domain import (
    GeofenceBatchQuery,
    GeofenceQuery,
    GeoPoint,
    PFZGeometryInput,
    RestrictedZone,
)
from app.services.mock.providers import DemoRestrictedZoneProvider

MPA_ZONE_ID = "mpa-coral-reef-01"


class StaticRestrictedZoneProvider:
    def __init__(self, zones: list[RestrictedZone]) -> None:
        self.zones = zones

    def get_restricted_zones(self) -> list[RestrictedZone]:
        return self.zones


def _zone(zone_id: str = "mpa-1", coordinates: list | None = None) -> RestrictedZone:
    coordinates = coordinates or [[80.30, 13.10], [80.32, 13.10], [80.32, 13.12], [80.30, 13.12], [80.30, 13.10]]
    return RestrictedZone(
        zone_id=zone_id,
        name="Test Marine Protected Area",
        restriction_type="marine_protected_area",
        geometry={"type": "Polygon", "coordinates": [coordinates]},
    )


def test_geofence_query_rejects_invalid_latitude() -> None:
    with pytest.raises(ValidationError, match="latitude"):
        GeofenceQuery(location=GeoPoint(latitude=91.0, longitude=80.0))


def test_geofence_query_rejects_invalid_longitude() -> None:
    with pytest.raises(ValidationError, match="longitude"):
        GeofenceQuery(location=GeoPoint(latitude=13.0, longitude=181.0))


def test_check_location_inside_restricted_zone_returns_clear_warning() -> None:
    agent = GeofencingAgent(StaticRestrictedZoneProvider([_zone()]))
    result = agent.check_location(GeofenceQuery(location=GeoPoint(latitude=13.11, longitude=80.31)))

    assert result.status == "success"
    assert result.inside_restricted_zone is True
    assert len(result.violations) == 1
    violation = result.violations[0]
    assert violation.zone_id == "mpa-1"
    assert violation.restriction_type == "marine_protected_area"
    assert "restricted or prohibited" in violation.message


def test_check_location_outside_restricted_zone_reports_no_violation() -> None:
    agent = GeofencingAgent(StaticRestrictedZoneProvider([_zone()]))
    result = agent.check_location(GeofenceQuery(location=GeoPoint(latitude=1.0, longitude=1.0)))

    assert result.status == "success"
    assert result.inside_restricted_zone is False
    assert result.violations == []


def test_check_location_against_seeded_demo_restricted_zones() -> None:
    agent = GeofencingAgent(DemoRestrictedZoneProvider())
    inside = agent.check_location(GeofenceQuery(location=GeoPoint(latitude=13.11, longitude=80.31)))
    outside = agent.check_location(GeofenceQuery(location=GeoPoint(latitude=1.0, longitude=1.0)))

    assert inside.inside_restricted_zone is True
    assert [violation.zone_id for violation in inside.violations] == [MPA_ZONE_ID]
    assert outside.inside_restricted_zone is False


def test_check_location_with_malformed_zone_geometry_reports_unavailable() -> None:
    broken = _zone()
    broken.geometry = {"type": "Polygon", "coordinates": [[[80.30, 13.10]]]}
    agent = GeofencingAgent(StaticRestrictedZoneProvider([broken]))

    result = agent.check_location(GeofenceQuery(location=GeoPoint(latitude=13.11, longitude=80.31)))

    assert result.status == "unavailable"
    assert result.inside_restricted_zone is False
    assert result.warnings


def test_execute_checks_both_location_and_pfzs_in_one_batch() -> None:
    agent = GeofencingAgent(StaticRestrictedZoneProvider([_zone()]))
    inside_pfz = PFZGeometryInput(
        pfz_id="pfz-inside",
        geometry={
            "type": "Polygon",
            "coordinates": [[[80.31, 13.11], [80.40, 13.11], [80.40, 13.20], [80.31, 13.20], [80.31, 13.11]]],
        },
    )
    outside_pfz = PFZGeometryInput(
        pfz_id="pfz-outside",
        geometry={
            "type": "Polygon",
            "coordinates": [[[10.0, 5.0], [10.1, 5.0], [10.1, 5.1], [10.0, 5.1], [10.0, 5.0]]],
        },
    )

    result = agent.execute(
        GeofenceBatchQuery(
            location=GeoPoint(latitude=13.11, longitude=80.31),
            pfzs=[inside_pfz, outside_pfz],
        )
    )

    assert result.status == "success"
    assert result.location_assessment.inside_restricted_zone is True

    by_id = {assessment.pfz_id: assessment for assessment in result.pfz_assessments}
    assert by_id["pfz-inside"].inside_restricted_zone is True
    assert by_id["pfz-inside"].violations[0].zone_id == "mpa-1"
    assert by_id["pfz-outside"].inside_restricted_zone is False


def test_execute_with_no_location_and_no_pfzs_is_unavailable() -> None:
    agent = GeofencingAgent(StaticRestrictedZoneProvider([_zone()]))
    result = agent.execute(GeofenceBatchQuery())

    assert result.status == "unavailable"
    assert result.location_assessment is None
    assert result.pfz_assessments == []
