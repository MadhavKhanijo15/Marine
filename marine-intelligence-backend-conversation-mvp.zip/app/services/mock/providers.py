from __future__ import annotations

import json
from pathlib import Path

from app.domain import (
    EvidenceItem,
    FishingZone,
    OceanConditions,
    OceanQuery,
    OceanSourceMetadata,
    PFZDataRecord,
    PFZSearchQuery,
    PFZSourceMetadata,
    PFZQuery,
    WeatherFinding,
    WeatherQuery,
    WeatherSourceMetadata,
)

DATA_DIR = Path(__file__).resolve().parents[2] / "data"


class DemoWeatherProvider:
    def get_forecast(self, query: WeatherQuery) -> WeatherFinding:
        payload = json.loads((DATA_DIR / "weather_demo.json").read_text(encoding="utf-8"))
        return WeatherFinding(
            location=query.location,
            time_window=query.time_window,
            observed_at=payload["observed_at"],
            source=WeatherSourceMetadata(**payload["source"]),
            wind_speed_knots=payload["wind_speed_knots"],
            wave_height_m=payload["wave_height_m"],
            rainfall_mm=payload["rainfall_mm"],
            visibility_km=payload["visibility_km"],
            thunderstorm_probability=payload["thunderstorm_probability"],
            alerts=payload["alerts"],
            evidence=[EvidenceItem(**payload["evidence"])],
        )


class DemoOceanDataProvider:
    """Loads seeded physical-ocean measurements for local MVP demonstrations."""

    def get_conditions(self, query: OceanQuery) -> OceanConditions:
        payload = json.loads((DATA_DIR / "ocean_demo.json").read_text(encoding="utf-8"))
        return OceanConditions(
            location=query.location,
            observed_at=payload["observed_at"],
            source=OceanSourceMetadata(**payload["source"]),
            sea_surface_temperature_c=payload["sea_surface_temperature_c"],
            chlorophyll_mg_m3=payload["chlorophyll_mg_m3"],
            wave_height_m=payload["wave_height_m"],
            wave_period_s=payload.get("wave_period_s"),
            sea_state=payload.get("sea_state"),
        )


class DemoPFZDataProvider:
    """Loads PFZ observations from the existing seeded PFZ GeoJSON file."""

    def get_pfz_records(self, query: PFZSearchQuery) -> list[PFZDataRecord]:
        payload = json.loads((DATA_DIR / "pfz_demo.geojson").read_text(encoding="utf-8"))
        return [
            PFZDataRecord(
                pfz_id=feature["properties"]["zone_id"],
                geometry=feature["geometry"],
                observed_at=feature["properties"]["observed_at"],
                source=PFZSourceMetadata(**feature["properties"]["source"]),
                sea_surface_temperature_c=feature["properties"].get("sea_surface_temperature_c"),
                chlorophyll_mg_m3=feature["properties"].get("chlorophyll_mg_m3"),
            )
            for feature in payload["features"]
        ]


class DemoOceanProvider:
    def get_candidate_zones(self, query: PFZQuery) -> list[FishingZone]:
        payload = json.loads((DATA_DIR / "pfz_demo.geojson").read_text(encoding="utf-8"))
        zones: list[FishingZone] = []
        for feature in payload["features"]:
            properties = feature["properties"]
            zones.append(
                FishingZone(
                    zone_id=properties["zone_id"],
                    geometry=feature["geometry"],
                    validity_window=query.time_window,
                    suitability_score=properties["suitability_score"],
                    species_hint=properties.get("species_hint"),
                    evidence=[EvidenceItem(**properties["evidence"])],
                )
            )
        return zones


class DemoHazardProvider:
    def get_hazards(self, query: PFZQuery) -> list[dict]:
        payload = json.loads((DATA_DIR / "hazards_demo.geojson").read_text(encoding="utf-8"))
        return payload["features"]
