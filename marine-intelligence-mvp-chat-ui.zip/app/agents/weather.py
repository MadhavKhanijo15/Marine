from app.domain import WeatherAgentResult, WeatherQuery
from app.services.interfaces import WeatherProvider


class WeatherAgent:
    """Provider adapter that exposes weather as an agent result."""

    def __init__(self, provider: WeatherProvider) -> None:
        self._provider = provider

    def execute(self, task: WeatherQuery) -> WeatherAgentResult:
        finding = self._provider.get_forecast(task)
        return WeatherAgentResult(
            status="success", findings=[finding], evidence=finding.evidence
        )

