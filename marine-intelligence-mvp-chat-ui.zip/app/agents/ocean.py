"""Ocean Intelligence Agent backed exclusively by an Ocean Data Service."""

from app.domain import OceanAgentResult, OceanQuery
from app.services.interfaces import OceanDataProvider


class OceanIntelligenceAgent:
    """Retrieves validated ocean conditions without PFZ or decision logic."""

    def __init__(self, provider: OceanDataProvider) -> None:
        self._provider = provider

    def execute(self, task: OceanQuery) -> OceanAgentResult:
        return OceanAgentResult(status="success", conditions=self._provider.get_conditions(task))

