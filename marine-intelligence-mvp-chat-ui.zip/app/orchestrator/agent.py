"""Main Orchestrator Agent: parses a query and fans out to specialist agents.

This module performs no independent domain calculations of its own. It only
parses free text (see ``app.orchestrator.parser``) and combines the already
structured outputs of the existing Weather, Ocean, PFZ, Geospatial, Risk, and
(optionally) Geofencing components -- each result field is exactly what that
component's own ``execute``/``assess``/``check_location`` returned, reused
rather than recomputed. It does no routing/navigation and keeps no memory
between calls: each ``execute`` call is independent and stateless.

Every provider-backed agent call is wrapped so a failing/missing data source
degrades to a warning and a ``None`` result for that component instead of
crashing the whole briefing -- callers (including the risk engine, which
already treats missing weather/ocean data as "unavailable", never "safe")
see exactly the same graceful-degradation contract whether a component was
never requested or was requested but failed.
"""

from __future__ import annotations

from typing import Callable, TypeVar

from app.agents.geofencing import GeofencingAgent
from app.agents.geospatial import GeospatialAgent
from app.agents.ocean import OceanIntelligenceAgent
from app.agents.pfz_fishing import PFZFishingIntelligenceAgent
from app.agents.weather import WeatherAgent
from app.domain import (
    ConversationContext,
    DataStatus,
    GeofenceQuery,
    GeospatialPFZQuery,
    OceanQuery,
    OrchestratorQuery,
    OrchestratorResult,
    PFZSearchQuery,
    RiskAssessmentInput,
    WeatherQuery,
)
from app.orchestrator.parser import parse_query
from app.recommendations import EvidenceRecommendationService
from app.risk.engine import RiskEngine

DEFAULT_GEOSPATIAL_RADIUS_KM = 25.0

_T = TypeVar("_T")


def _safe_call(label: str, call: Callable[[], _T], warnings: list[str]) -> _T | None:
    """Run one provider-backed agent call; on failure, warn and return None.

    This is the orchestrator's single error boundary around external data
    sources: a bad/unavailable provider must never crash the whole briefing,
    and it must never be silently treated as "no restriction"/"safe" -- it
    always surfaces as an explicit warning instead.
    """
    try:
        return call()
    except Exception as exc:  # noqa: BLE001 - intentional broad boundary around I/O
        warnings.append(f"{label} unavailable: {exc}")
        return None


class MainOrchestratorAgent:
    """Interprets one natural-language query and calls only the components it needs."""

    def __init__(
        self,
        weather_agent: WeatherAgent,
        ocean_agent: OceanIntelligenceAgent,
        pfz_agent: PFZFishingIntelligenceAgent,
        geospatial_agent: GeospatialAgent,
        risk_engine: RiskEngine,
        geofence_agent: GeofencingAgent | None = None,
        recommendation_service: EvidenceRecommendationService | None = None,
    ) -> None:
        self._weather_agent = weather_agent
        self._ocean_agent = ocean_agent
        self._pfz_agent = pfz_agent
        self._geospatial_agent = geospatial_agent
        self._risk_engine = risk_engine
        self._geofence_agent = geofence_agent
        self._recommendation_service = recommendation_service or EvidenceRecommendationService()

    def execute(self, task: OrchestratorQuery) -> OrchestratorResult:
        parsed = parse_query(task.text, now=task.requested_at)
        warnings = list(parsed.warnings)
        components = parsed.components
        context = task.context
        location = parsed.location or (context.location if context else None)
        if parsed.location is None and location is not None:
            warnings = [warning for warning in warnings if "No latitude/longitude" not in warning]
        if context and context.time_window and not parsed.time_window_explicit:
            parsed.time_window = context.time_window
        if context and not parsed.selected_pfz_id:
            parsed.selected_pfz_id = context.selected_pfz_id
        parsed.location = location
        parsed.warnings = warnings

        weather_result = None
        ocean_result = None
        pfz_result = None
        geospatial_result = None
        risk_result = None
        geofence_result = None

        needs_weather = components.weather or components.risk
        needs_ocean = components.ocean or components.risk
        needs_location = (
            needs_weather or needs_ocean or components.pfz or components.geospatial or components.geofence
        )

        if location is None:
            if needs_location:
                warnings.append("Skipped location-dependent components because no valid location was found.")
        else:
            if needs_weather:
                weather_result = _safe_call(
                    "Weather data",
                    lambda: self._weather_agent.execute(
                        WeatherQuery(location=location, time_window=parsed.time_window)
                    ),
                    warnings,
                )

            if needs_ocean:
                ocean_result = _safe_call(
                    "Ocean data",
                    lambda: self._ocean_agent.execute(
                        OceanQuery(location=location, time_window=parsed.time_window)
                    ),
                    warnings,
                )

            if components.geospatial:
                radius_km = parsed.radius_km or DEFAULT_GEOSPATIAL_RADIUS_KM
                geospatial_result = _safe_call(
                    "Nearby fishing-zone data",
                    lambda: self._geospatial_agent.execute(
                        GeospatialPFZQuery(
                            latitude=location.latitude, longitude=location.longitude, radius_km=radius_km
                        )
                    ),
                    warnings,
                )
            elif components.pfz:
                pfz_result = _safe_call(
                    "Fishing-zone data",
                    lambda: self._pfz_agent.execute(
                        PFZSearchQuery(latitude=location.latitude, longitude=location.longitude)
                    ),
                    warnings,
                )

            if components.geofence and self._geofence_agent is not None:
                # No geofence_agent configured is a deliberate configuration
                # choice (as with RouteOptimizationAgent's optional risk
                # inputs), not missing data -- so it stays silent rather than
                # adding a warning to every caller that doesn't wire one in.
                geofence_result = _safe_call(
                    "Restricted-zone check",
                    lambda: self._geofence_agent.check_location(GeofenceQuery(location=location)),
                    warnings,
                )
                if geofence_result is not None and geofence_result.inside_restricted_zone:
                    # Surface each violation as a warning -- this is the only
                    # change needed for the existing, unmodified
                    # recommendation service to carry it through, since it
                    # already forwards ``result.warnings`` verbatim.
                    warnings.extend(violation.message for violation in geofence_result.violations)

            if components.risk:
                if weather_result is None:
                    warnings.append("Risk assessment skipped: weather data unavailable.")
                else:
                    # Reuse the weather/ocean agents' own outputs as the risk
                    # engine's inputs -- no distance/score is recalculated here.
                    risk_result = self._risk_engine.assess(
                        RiskAssessmentInput(
                            weather=weather_result.findings[0],
                            ocean=ocean_result.conditions if ocean_result else None,
                        )
                    )

        results = (weather_result, ocean_result, pfz_result, geospatial_result, risk_result, geofence_result)
        if warnings and not any(result is not None for result in results):
            status = DataStatus.UNAVAILABLE
        elif warnings:
            status = DataStatus.PARTIAL
        else:
            status = DataStatus.SUCCESS

        result = OrchestratorResult(
            status=status,
            parsed_query=parsed,
            weather=weather_result,
            ocean=ocean_result,
            pfz=pfz_result,
            geospatial=geospatial_result,
            risk=risk_result,
            geofence=geofence_result,
            resolved_context=(
                context.model_copy(update={"location": location, "time_window": parsed.time_window})
                if context
                else None
            ),
            warnings=warnings,
        )
        result.evidence_recommendation = self._recommendation_service.build(result)
        return result


def build_demo_orchestrator() -> MainOrchestratorAgent:
    """Wire the orchestrator to the existing demo/mock providers for local use.

    Nothing here changes the API surface (no routes are added) -- this is
    purely a convenience constructor mirroring how each specialist agent is
    already wired to its demo provider in tests.
    """

    from app.risk.engine import DeterministicRiskEngine
    from app.services.mock.providers import (
        DemoOceanDataProvider,
        DemoPFZDataProvider,
        DemoRestrictedZoneProvider,
        DemoWeatherProvider,
    )

    return MainOrchestratorAgent(
        weather_agent=WeatherAgent(DemoWeatherProvider()),
        ocean_agent=OceanIntelligenceAgent(DemoOceanDataProvider()),
        pfz_agent=PFZFishingIntelligenceAgent(DemoPFZDataProvider()),
        geospatial_agent=GeospatialAgent(DemoPFZDataProvider()),
        risk_engine=DeterministicRiskEngine(),
        geofence_agent=GeofencingAgent(DemoRestrictedZoneProvider()),
    )
