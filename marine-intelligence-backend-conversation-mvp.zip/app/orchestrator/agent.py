"""Main Orchestrator Agent: parses a query and fans out to specialist agents.

This module performs no independent domain calculations of its own. It only
parses free text (see ``app.orchestrator.parser``) and combines the already
structured outputs of the existing Weather, Ocean, PFZ, Geospatial, and Risk
components -- each result field is exactly what that component's own
``execute``/``assess`` returned, reused rather than recomputed. It does no
routing/navigation, no geofencing, and keeps no memory between calls: each
``execute`` call is independent and stateless.
"""

from __future__ import annotations

from app.agents.geospatial import GeospatialAgent
from app.agents.ocean import OceanIntelligenceAgent
from app.agents.pfz_fishing import PFZFishingIntelligenceAgent
from app.agents.weather import WeatherAgent
from app.domain import (
    ConversationContext,
    DataStatus,
    GeospatialPFZQuery,
    OceanQuery,
    OrchestratorQuery,
    OrchestratorResult,
    PFZSearchQuery,
    RiskAssessmentInput,
    WeatherQuery,
)
from app.orchestrator.parser import parse_query
from app.recommendations import EvidenceRecommendationService
from app.risk.engine import RiskEngine

DEFAULT_GEOSPATIAL_RADIUS_KM = 25.0


class MainOrchestratorAgent:
    """Interprets one natural-language query and calls only the components it needs."""

    def __init__(
        self,
        weather_agent: WeatherAgent,
        ocean_agent: OceanIntelligenceAgent,
        pfz_agent: PFZFishingIntelligenceAgent,
        geospatial_agent: GeospatialAgent,
        risk_engine: RiskEngine,
        recommendation_service: EvidenceRecommendationService | None = None,
    ) -> None:
        self._weather_agent = weather_agent
        self._ocean_agent = ocean_agent
        self._pfz_agent = pfz_agent
        self._geospatial_agent = geospatial_agent
        self._risk_engine = risk_engine
        self._recommendation_service = recommendation_service or EvidenceRecommendationService()

    def execute(self, task: OrchestratorQuery) -> OrchestratorResult:
        parsed = parse_query(task.text, now=task.requested_at)
        warnings = list(parsed.warnings)
        components = parsed.components
        context = task.context
        location = parsed.location or (context.location if context else None)
        if parsed.location is None and location is not None:
            warnings = [warning for warning in warnings if "No latitude/longitude" not in warning]
        if context and context.time_window and not parsed.time_window_explicit:
            parsed.time_window = context.time_window
        if context and not parsed.selected_pfz_id:
            parsed.selected_pfz_id = context.selected_pfz_id
        parsed.location = location
        parsed.warnings = warnings

        weather_result = None
        ocean_result = None
        pfz_result = None
        geospatial_result = None
        risk_result = None

        needs_weather = components.weather or components.risk
        needs_ocean = components.ocean or components.risk
        needs_location = needs_weather or needs_ocean or components.pfz or components.geospatial

        if location is None:
            if needs_location:
                warnings.append("Skipped location-dependent components because no valid location was found.")
        else:
            if needs_weather:
                weather_result = self._weather_agent.execute(
                    WeatherQuery(location=location, time_window=parsed.time_window)
                )

            if needs_ocean:
                ocean_result = self._ocean_agent.execute(
                    OceanQuery(location=location, time_window=parsed.time_window)
                )

            if components.geospatial:
                radius_km = parsed.radius_km or DEFAULT_GEOSPATIAL_RADIUS_KM
                geospatial_result = self._geospatial_agent.execute(
                    GeospatialPFZQuery(
                        latitude=location.latitude, longitude=location.longitude, radius_km=radius_km
                    )
                )
            elif components.pfz:
                pfz_result = self._pfz_agent.execute(
                    PFZSearchQuery(latitude=location.latitude, longitude=location.longitude)
                )

            if components.risk:
                if weather_result is None:
                    warnings.append("Risk assessment skipped: weather data unavailable.")
                else:
                    # Reuse the weather/ocean agents' own outputs as the risk
                    # engine's inputs -- no distance/score is recalculated here.
                    risk_result = self._risk_engine.assess(
                        RiskAssessmentInput(
                            weather=weather_result.findings[0],
                            ocean=ocean_result.conditions if ocean_result else None,
                        )
                    )

        results = (weather_result, ocean_result, pfz_result, geospatial_result, risk_result)
        if warnings and not any(result is not None for result in results):
            status = DataStatus.UNAVAILABLE
        elif warnings:
            status = DataStatus.PARTIAL
        else:
            status = DataStatus.SUCCESS

        result = OrchestratorResult(
            status=status,
            parsed_query=parsed,
            weather=weather_result,
            ocean=ocean_result,
            pfz=pfz_result,
            geospatial=geospatial_result,
            risk=risk_result,
            resolved_context=(
                context.model_copy(update={"location": location, "time_window": parsed.time_window})
                if context
                else None
            ),
            warnings=warnings,
        )
        result.evidence_recommendation = self._recommendation_service.build(result)
        return result


def build_demo_orchestrator() -> MainOrchestratorAgent:
    """Wire the orchestrator to the existing demo/mock providers for local use.

    Nothing here changes the API surface (no routes are added) -- this is
    purely a convenience constructor mirroring how each specialist agent is
    already wired to its demo provider in tests.
    """

    from app.risk.engine import DeterministicRiskEngine
    from app.services.mock.providers import (
        DemoOceanDataProvider,
        DemoPFZDataProvider,
        DemoWeatherProvider,
    )

    return MainOrchestratorAgent(
        weather_agent=WeatherAgent(DemoWeatherProvider()),
        ocean_agent=OceanIntelligenceAgent(DemoOceanDataProvider()),
        pfz_agent=PFZFishingIntelligenceAgent(DemoPFZDataProvider()),
        geospatial_agent=GeospatialAgent(DemoPFZDataProvider()),
        risk_engine=DeterministicRiskEngine(),
    )
