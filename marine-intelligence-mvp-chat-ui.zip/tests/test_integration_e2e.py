"""End-to-end integration tests for the Marine Intelligence MVP.

These exercise the real orchestrator -> agent -> provider flow (the same
wiring ``build_demo_orchestrator()``/``main.py`` use), not isolated units,
to verify:
  - correct orchestrator -> agent flow and data passing
  - deterministic risk engine results (same input -> same output, always)
  - recommendations only ever surface data an agent actually returned
  - no numerical value is invented anywhere in the chain
  - missing/failing weather or ocean data degrades gracefully, never crashes
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

import pytest
from pydantic import ValidationError

from app.agents.geofencing import GeofencingAgent
from app.agents.geospatial import GeospatialAgent
from app.agents.ocean import OceanIntelligenceAgent
from app.agents.pfz_fishing import PFZFishingIntelligenceAgent
from app.agents.weather import WeatherAgent
from app.conversation import ConversationService
from app.domain import ConversationTurnRequest, GeoPoint, OrchestratorQuery
from app.geospatial.service import haversine_distance_km
from app.orchestrator.agent import MainOrchestratorAgent, build_demo_orchestrator
from app.risk.engine import DeterministicRiskEngine
from app.services.mock.providers import (
    DemoOceanDataProvider,
    DemoPFZDataProvider,
    DemoRestrictedZoneProvider,
    DemoWeatherProvider,
)

NOW = datetime(2026, 9, 12, 6, tzinfo=timezone.utc)

# Demo data constants (from app/data/*), asserted against directly so a test
# failure means the pipeline actually diverged from the seeded source data.
DEMO_WIND_KNOTS = 12
DEMO_WAVE_M = 1.1
DEMO_SEA_STATE = "slight"
DEMO_SEA_STATE_POINTS = 5  # RiskPolicy.sea_state_points["slight"]
PFZ_ALPHA_CENTROID = GeoPoint(latitude=13.015, longitude=80.215)
MPA_ZONE_ID = "mpa-coral-reef-01"


class BrokenWeatherProvider:
    """Simulates a weather data source that is entirely unavailable."""

    def get_forecast(self, query):
        raise RuntimeError("weather upstream timed out")


class BrokenOceanProvider:
    """Simulates an ocean data source that is entirely unavailable."""

    def get_conditions(self, query):
        raise RuntimeError("ocean upstream returned 503")


def _demo_orchestrator_with(weather_provider=None, ocean_provider=None) -> MainOrchestratorAgent:
    """Same wiring as build_demo_orchestrator(), with one provider swapped out."""
    return MainOrchestratorAgent(
        weather_agent=WeatherAgent(weather_provider or DemoWeatherProvider()),
        ocean_agent=OceanIntelligenceAgent(ocean_provider or DemoOceanDataProvider()),
        pfz_agent=PFZFishingIntelligenceAgent(DemoPFZDataProvider()),
        geospatial_agent=GeospatialAgent(DemoPFZDataProvider()),
        risk_engine=DeterministicRiskEngine(),
        geofence_agent=GeofencingAgent(DemoRestrictedZoneProvider()),
    )


# ---------------------------------------------------------------------------
# Scenario 1: Fishing safety query for Chennai tomorrow morning
# ---------------------------------------------------------------------------


def test_fishing_safety_query_for_chennai_tomorrow() -> None:
    orchestrator = build_demo_orchestrator()
    result = orchestrator.execute(
        OrchestratorQuery(
            text="Is it safe to go fishing near Chennai at 13.08, 80.27 tomorrow morning?",
            requested_at=NOW,
        )
    )

    assert result.status == "success"
    assert result.parsed_query.location == GeoPoint(latitude=13.08, longitude=80.27)
    # "tomorrow" is recognized; the parser has no clock-time grammar, so the
    # window starts at the same time-of-day tomorrow (a known MVP limit, not
    # a crash) rather than snapping to a literal "morning".
    assert result.parsed_query.time_window.start == NOW + timedelta(days=1)

    # Weather/ocean data passed through untouched from the seeded source.
    assert result.weather.findings[0].wind_speed_knots == DEMO_WIND_KNOTS
    assert result.ocean.conditions.sea_state == DEMO_SEA_STATE

    # Deterministic risk: only sea_state ("slight") contributes points here.
    assert result.risk.overall_score == DEMO_SEA_STATE_POINTS
    assert result.risk.category == "low"
    assert result.risk.recommendation == "go"
    # The risk engine's inputs are literally the weather/ocean agents' own
    # returned values -- never independently recomputed or invented.
    assert result.risk.reproducibility_inputs["weather"]["wind_speed_knots"] == DEMO_WIND_KNOTS
    assert result.risk.reproducibility_inputs["ocean"]["sea_state"] == DEMO_SEA_STATE

    # The evidence/recommendation view only ever echoes already-returned data.
    rec = result.evidence_recommendation
    assert rec.recommendation == result.risk.recommendation
    assert rec.overall_risk_score == result.risk.overall_score
    wind_value = next(v for v in rec.relevant_values if v.field == "wind_speed_knots")
    assert wind_value.value == DEMO_WIND_KNOTS


def test_risk_engine_is_deterministic_across_repeated_identical_calls() -> None:
    orchestrator = build_demo_orchestrator()
    query = OrchestratorQuery(text="Is it safe to go fishing at 13.08, 80.27?", requested_at=NOW)

    first = orchestrator.execute(query)
    second = orchestrator.execute(query)

    assert first.risk.overall_score == second.risk.overall_score
    assert first.risk.category == second.risk.category
    assert first.risk.recommendation == second.risk.recommendation
    assert first.risk.model_dump(mode="json") == second.risk.model_dump(mode="json")


# ---------------------------------------------------------------------------
# Scenario 2: Nearest suitable fishing zone
# ---------------------------------------------------------------------------


def test_nearest_suitable_fishing_zone_query() -> None:
    orchestrator = build_demo_orchestrator()
    origin = GeoPoint(latitude=13.08, longitude=80.27)
    result = orchestrator.execute(
        OrchestratorQuery(text=f"Find the nearest suitable fishing zone near {origin.latitude}, {origin.longitude}", requested_at=NOW)
    )

    assert result.status == "success"
    assert result.pfz is not None
    assert result.geospatial is None  # no radius named -> plain nearest-zone listing
    nearest = result.pfz.nearby_pfzs[0]
    assert nearest.pfz_id == "pfz-alpha"
    # The distance is exactly what the same deterministic haversine helper
    # the agent itself uses would compute -- nothing is estimated ad hoc.
    expected_km = round(haversine_distance_km(origin, PFZ_ALPHA_CENTROID), 3)
    assert nearest.distance_km == expected_km


# ---------------------------------------------------------------------------
# Scenario 3: Follow-up with 6 AM departure
# ---------------------------------------------------------------------------


def test_follow_up_with_6am_departure_reuses_context_gracefully() -> None:
    service = ConversationService(build_demo_orchestrator())
    first = service.execute(
        ConversationTurnRequest(
            conversation_id="dawn-trip",
            text="Is it safe to go fishing at 13.015, 80.215?",
            requested_at=NOW,
            selected_pfz_id="pfz-alpha",
        )
    )
    follow_up = service.execute(
        ConversationTurnRequest(
            conversation_id="dawn-trip",
            text="Is it still safe if we leave at 6 AM tomorrow instead?",
            requested_at=NOW,
        )
    )

    # Location and PFZ selection from turn 1 carry forward untouched.
    assert follow_up.context.location == first.context.location == GeoPoint(latitude=13.015, longitude=80.215)
    assert follow_up.context.selected_pfz_id == "pfz-alpha"
    # "tomorrow" is recognized and shifts the date; "6 AM" has no parser
    # grammar, so the window is not silently guessed at a literal 6 AM --
    # it degrades to the same explicit-date/default-duration behavior as
    # any other "tomorrow" query, rather than inventing a clock time.
    assert follow_up.context.time_window.start == NOW + timedelta(days=1)
    assert follow_up.result.status == "success"
    assert follow_up.result.risk is not None
    assert follow_up.result.parsed_query.location == first.context.location


# ---------------------------------------------------------------------------
# Scenario 4: Restricted/geofenced area query
# ---------------------------------------------------------------------------


def test_restricted_area_query_is_flagged_end_to_end() -> None:
    orchestrator = build_demo_orchestrator()
    result = orchestrator.execute(
        OrchestratorQuery(
            text="Am I allowed to fish at 13.11, 80.31? Is this a restricted area?",
            requested_at=NOW,
        )
    )

    assert result.parsed_query.components.geofence is True
    assert result.geofence is not None
    assert result.geofence.inside_restricted_zone is True
    assert result.geofence.violations[0].zone_id == MPA_ZONE_ID
    # The violation is surfaced as a warning through the *existing*,
    # unmodified recommendation pipeline (no new recommendation fields).
    assert any("Chennai Coastal Marine Protected Area" in warning for warning in result.warnings)
    assert any("restricted or prohibited" in warning for warning in result.warnings)
    assert result.evidence_recommendation.warnings == result.warnings
    assert result.status == "partial"  # data was returned, but a restriction applies


def test_query_outside_any_restricted_zone_is_not_flagged() -> None:
    orchestrator = build_demo_orchestrator()
    result = orchestrator.execute(
        OrchestratorQuery(text="Is 1.0, 1.0 a restricted area for fishing?", requested_at=NOW)
    )

    assert result.geofence is not None
    assert result.geofence.inside_restricted_zone is False
    assert result.geofence.violations == []
    assert not any("restricted" in warning.lower() for warning in result.warnings)


def test_geofence_check_is_skipped_silently_when_not_configured() -> None:
    # An orchestrator built without a geofence_agent (as most existing tests
    # in this suite already do) must keep working exactly as before: no
    # crash, no spurious warning, geofence simply stays unset.
    orchestrator = MainOrchestratorAgent(
        weather_agent=WeatherAgent(DemoWeatherProvider()),
        ocean_agent=OceanIntelligenceAgent(DemoOceanDataProvider()),
        pfz_agent=PFZFishingIntelligenceAgent(DemoPFZDataProvider()),
        geospatial_agent=GeospatialAgent(DemoPFZDataProvider()),
        risk_engine=DeterministicRiskEngine(),
    )
    result = orchestrator.execute(
        OrchestratorQuery(text="Is 13.11, 80.31 a restricted area?", requested_at=NOW)
    )

    assert result.geofence is None
    assert result.warnings == []
    assert result.status == "success"


# ---------------------------------------------------------------------------
# Scenario 5: Query with missing weather/ocean data
# ---------------------------------------------------------------------------


def test_missing_weather_data_degrades_gracefully_without_inventing_risk() -> None:
    orchestrator = _demo_orchestrator_with(weather_provider=BrokenWeatherProvider())
    result = orchestrator.execute(
        OrchestratorQuery(text="Is it safe to go fishing at 13.015, 80.215?", requested_at=NOW)
    )

    assert result.weather is None
    assert result.risk is None  # never fabricated when its required input is missing
    assert result.ocean is not None  # ocean provider was unaffected
    assert result.pfz is not None  # unrelated components still work
    assert any("Weather data unavailable" in warning for warning in result.warnings)
    assert any("Risk assessment skipped" in warning for warning in result.warnings)
    assert result.status == "partial"
    assert result.evidence_recommendation is not None
    assert result.evidence_recommendation.recommendation is None


def test_missing_ocean_data_still_computes_risk_without_inventing_sea_state() -> None:
    orchestrator = _demo_orchestrator_with(ocean_provider=BrokenOceanProvider())
    result = orchestrator.execute(
        OrchestratorQuery(text="Is it safe to go fishing at 13.015, 80.215?", requested_at=NOW)
    )

    assert result.ocean is None
    assert result.weather is not None
    assert any("Ocean data unavailable" in warning for warning in result.warnings)
    # Risk can still run on weather alone -- but sea_state must be reported
    # as unavailable, never assumed calm/safe.
    assert result.risk is not None
    sea_state_factor = next(f for f in result.risk.factors if f.id == "sea_state")
    assert sea_state_factor.data_available is False
    assert sea_state_factor.measured_value is None
    assert sea_state_factor.contribution_points == 0
    assert sea_state_factor.reason_code == "SEA_STATE_DATA_UNAVAILABLE"
    assert result.status == "partial"


def test_missing_location_across_all_components_is_handled_safely() -> None:
    orchestrator = build_demo_orchestrator()
    result = orchestrator.execute(
        OrchestratorQuery(text="Is it safe to go fishing right now?", requested_at=NOW)
    )

    assert result.status == "unavailable"
    assert result.weather is None
    assert result.ocean is None
    assert result.pfz is None
    assert result.risk is None
    assert result.geofence is None
    assert any("location" in warning.lower() for warning in result.warnings)


def test_invalid_conversation_request_is_rejected_before_reaching_agents() -> None:
    with pytest.raises(ValidationError):
        ConversationTurnRequest(conversation_id="", text="Is it safe to fish?")
