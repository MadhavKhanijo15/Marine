from pathlib import Path

from fastapi import FastAPI, Query
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.conversation import ConversationService
from app.domain import ConversationTurnRequest, ConversationTurnResult, OrchestratorQuery, OrchestratorResult
from app.orchestrator.agent import build_demo_orchestrator

app = FastAPI(title="Marine Intelligence Assistant API", version="0.1.0")
FRONTEND_DIR = Path(__file__).resolve().parents[1] / "frontend"
app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")
conversation_service = ConversationService(build_demo_orchestrator())


@app.get("/health", tags=["system"])
def health() -> dict[str, str]:
    """Basic liveness endpoint; no external dependency is checked here."""
    return {"status": "ok", "service": "marine-intelligence-backend"}


@app.get("/", include_in_schema=False)
def marine_map() -> FileResponse:
    """Serve the stateless MVP map client from the same origin as the API."""
    return FileResponse(FRONTEND_DIR / "index.html")


@app.get("/api/marine-briefing", response_model=OrchestratorResult, tags=["marine"])
def marine_briefing(
    latitude: float = Query(ge=-90, le=90),
    longitude: float = Query(ge=-180, le=180),
) -> OrchestratorResult:
    """Return agent-owned marine data for one map location.

    The browser supplies only the location. Existing agents calculate PFZ
    distances and risk; this endpoint performs no routing, geofencing, or
    cross-request memory.
    """
    return build_demo_orchestrator().execute(
        OrchestratorQuery(text=f"marine briefing at {latitude}, {longitude}")
    )


@app.post("/api/conversations/turn", response_model=ConversationTurnResult, tags=["marine"])
def conversation_turn(turn: ConversationTurnRequest) -> ConversationTurnResult:
    """Resolve a follow-up using only context already supplied in this conversation."""
    return conversation_service.execute(turn)
