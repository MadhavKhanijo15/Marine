"""Deterministic MVP route planning: a straight line, or one simple detour.

This is intentionally basic, not professional maritime navigation -- there is
no depth data, traffic-separation scheme, current/tide modeling, or general
pathfinding here. Given a start and destination, it:

  1. Checks the direct line against the supplied restricted zones (reusing
     ``app.geospatial.service.find_zones_intersecting_geometry`` -- no new
     GeoJSON parsing or containment logic is duplicated here).
  2. If the direct line is already clear, returns it unchanged.
  3. If it is blocked, tries exactly two deterministic single-waypoint
     detours around the combined bounding box of the blocking zones (one to
     the north, one to the south of the obstacle), and returns whichever is
     shorter and itself fully clear. Ties favor the northern detour.
  4. If neither simple detour is clear, the direct route is returned flagged
     as not clear, together with the zones blocking it -- this module never
     invents a path it has not itself verified as clear.
"""

from __future__ import annotations

from dataclasses import dataclass

from shapely.geometry import shape
from shapely.ops import unary_union

from app.domain import GeoPoint, RestrictedZone
from app.geospatial.service import find_zones_intersecting_geometry, haversine_distance_km

ROUTE_CALCULATION_VERSION = "route-mvp-1"

# MVP-only clearance margin (degrees) used to place a detour waypoint outside
# a blocking zone's bounding box. This is a demo convenience, not a validated
# navigational safety buffer.
DETOUR_CLEARANCE_DEGREES = 0.02


@dataclass(frozen=True)
class RoutePlan:
    coordinates: list[GeoPoint]
    distance_km: float
    detoured: bool
    clear_of_restricted_zones: bool
    blocking_zones: list[RestrictedZone]


def _path_geometry(points: list[GeoPoint]) -> dict:
    return {"type": "LineString", "coordinates": [[point.longitude, point.latitude] for point in points]}


def _path_distance_km(points: list[GeoPoint]) -> float:
    return round(sum(haversine_distance_km(points[i], points[i + 1]) for i in range(len(points) - 1)), 3)


def plan_route(start: GeoPoint, destination: GeoPoint, zones: list[RestrictedZone]) -> RoutePlan:
    """Deterministically plan a simple MVP route from start to destination.

    May raise ``app.geospatial.service.InvalidGeometryError`` if a supplied
    restricted-zone geometry cannot be parsed; callers should treat that as
    "route safety could not be verified", not as a clear route.
    """
    direct = [start, destination]
    blocking = find_zones_intersecting_geometry(_path_geometry(direct), zones)
    if not blocking:
        return RoutePlan(
            coordinates=direct,
            distance_km=_path_distance_km(direct),
            detoured=False,
            clear_of_restricted_zones=True,
            blocking_zones=[],
        )

    union_shape = unary_union([shape(zone.geometry) for zone in blocking])
    min_x, min_y, max_x, max_y = union_shape.bounds
    mid_x = (min_x + max_x) / 2
    margin = DETOUR_CLEARANCE_DEGREES

    candidates: list[tuple[str, list[GeoPoint]]] = [
        ("north", [start, GeoPoint(latitude=max_y + margin, longitude=mid_x), destination]),
        ("south", [start, GeoPoint(latitude=min_y - margin, longitude=mid_x), destination]),
    ]

    clear_candidates: list[tuple[list[GeoPoint], float]] = []
    for _label, coords in candidates:
        still_blocking = find_zones_intersecting_geometry(_path_geometry(coords), zones)
        if not still_blocking:
            clear_candidates.append((coords, _path_distance_km(coords)))

    if clear_candidates:
        # Shortest distance wins; ``min`` keeps the first (north) on a tie.
        best_coords, best_distance = min(clear_candidates, key=lambda item: item[1])
        return RoutePlan(
            coordinates=best_coords,
            distance_km=best_distance,
            detoured=True,
            clear_of_restricted_zones=True,
            blocking_zones=blocking,
        )

    # Neither simple detour is fully clear: this MVP does not attempt more
    # complex pathfinding, so it returns the direct route flagged as blocked
    # rather than returning an unverified path.
    return RoutePlan(
        coordinates=direct,
        distance_km=_path_distance_km(direct),
        detoured=False,
        clear_of_restricted_zones=False,
        blocking_zones=blocking,
    )
