"""Geospatial Agent: deterministic distance and radius filtering for PFZ candidates."""

from app.domain import GeospatialAgentResult, GeospatialPFZQuery, NearbyPFZ
from app.geospatial.service import geometry_centroid, haversine_distance_km
from app.services.interfaces import PFZDataProvider


class GeospatialAgent:
    """Computes user->PFZ distance and filters candidates to a radius, deterministically.

    No routing, geofencing, or risk logic lives here: this agent only validates the
    requested location, measures great-circle distance to each PFZ centroid, and
    excludes records beyond the requested radius.
    """

    def __init__(self, provider: PFZDataProvider) -> None:
        self._provider = provider

    def execute(self, task: GeospatialPFZQuery) -> GeospatialAgentResult:
        origin = task.location
        nearby_pfzs: list[NearbyPFZ] = []
        for record in self._provider.get_pfz_records(task):
            coordinates = geometry_centroid(record.geometry)
            distance_km = round(haversine_distance_km(origin, coordinates), 3)
            if distance_km > task.radius_km:
                continue
            nearby_pfzs.append(
                NearbyPFZ(
                    pfz_id=record.pfz_id,
                    coordinates=coordinates,
                    distance_km=distance_km,
                    observed_at=record.observed_at,
                    source=record.source,
                    sea_surface_temperature_c=record.sea_surface_temperature_c,
                    chlorophyll_mg_m3=record.chlorophyll_mg_m3,
                )
            )
        return GeospatialAgentResult(
            status="success",
            origin=origin,
            radius_km=task.radius_km,
            nearby_pfzs=sorted(nearby_pfzs, key=lambda item: item.distance_km),
        )
