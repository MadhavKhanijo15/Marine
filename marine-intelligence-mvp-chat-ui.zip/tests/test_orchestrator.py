from datetime import datetime, timezone

from app.agents.geospatial import GeospatialAgent
from app.agents.ocean import OceanIntelligenceAgent
from app.agents.pfz_fishing import PFZFishingIntelligenceAgent
from app.agents.weather import WeatherAgent
from app.domain import (
    GeoPoint,
    OceanConditions,
    OceanSourceMetadata,
    OrchestratorQuery,
    PFZDataRecord,
    PFZSourceMetadata,
    TimeWindow,
    WeatherFinding,
    WeatherSourceMetadata,
)
from app.orchestrator.agent import MainOrchestratorAgent
from app.orchestrator.parser import parse_query
from app.risk.engine import DeterministicRiskEngine

NOW = datetime(2026, 9, 12, 6, tzinfo=timezone.utc)


class SpyWeatherProvider:
    def __init__(self, response: WeatherFinding) -> None:
        self.response = response
        self.calls = 0

    def get_forecast(self, query):
        self.calls += 1
        return self.response


class SpyOceanProvider:
    def __init__(self, response: OceanConditions) -> None:
        self.response = response
        self.calls = 0

    def get_conditions(self, query):
        self.calls += 1
        return self.response


class SpyPFZProvider:
    def __init__(self, records: list[PFZDataRecord]) -> None:
        self.records = records
        self.calls = 0

    def get_pfz_records(self, query):
        self.calls += 1
        return self.records


def _weather_finding(**updates: object) -> WeatherFinding:
    values = {
        "location": GeoPoint(latitude=13.015, longitude=80.215),
        "time_window": TimeWindow(start=NOW, end=NOW.replace(hour=12)),
        "observed_at": NOW,
        "source": WeatherSourceMetadata(provider="test-provider", dataset="test-dataset", retrieved_at=NOW),
        "wind_speed_knots": 10,
        "wave_height_m": 1.0,
        "visibility_km": 8,
        "thunderstorm_probability": 0.1,
    }
    values.update(updates)
    return WeatherFinding(**values)


def _ocean_conditions(**updates: object) -> OceanConditions:
    values = {
        "location": GeoPoint(latitude=13.015, longitude=80.215),
        "observed_at": NOW,
        "source": OceanSourceMetadata(provider="test-provider", dataset="test-dataset", retrieved_at=NOW),
        "sea_surface_temperature_c": 28.0,
        "chlorophyll_mg_m3": 0.5,
        "wave_height_m": 1.0,
        "sea_state": "moderate",
    }
    values.update(updates)
    return OceanConditions(**values)


def _pfz_record(pfz_id: str, longitude: float, latitude: float) -> PFZDataRecord:
    source = PFZSourceMetadata(provider="test-provider", dataset="test-dataset", retrieved_at=NOW)
    return PFZDataRecord(
        pfz_id=pfz_id, geometry={"type": "Point", "coordinates": [longitude, latitude]}, observed_at=NOW, source=source
    )


def _build_orchestrator(
    weather_provider: SpyWeatherProvider,
    ocean_provider: SpyOceanProvider,
    pfz_provider: SpyPFZProvider,
) -> MainOrchestratorAgent:
    return MainOrchestratorAgent(
        weather_agent=WeatherAgent(weather_provider),
        ocean_agent=OceanIntelligenceAgent(ocean_provider),
        pfz_agent=PFZFishingIntelligenceAgent(pfz_provider),
        geospatial_agent=GeospatialAgent(pfz_provider),
        risk_engine=DeterministicRiskEngine(),
    )


# ---------------------------------------------------------------------------
# Parser-level tests
# ---------------------------------------------------------------------------


def test_parser_extracts_location_intent_and_time_for_weather_query() -> None:
    parsed = parse_query("What's the weather at 13.05, 80.20 over the next 3 hours?", now=NOW)
    assert parsed.location == GeoPoint(latitude=13.05, longitude=80.20)
    assert parsed.components.weather is True
    assert parsed.components.pfz is False
    assert parsed.time_window.start == NOW
    assert parsed.time_window.end == NOW.replace(hour=9)
    assert parsed.warnings == []


def test_parser_flags_pfz_with_radius_as_geospatial() -> None:
    parsed = parse_query("Find fishing zones within 20 km of 13.0, 80.0", now=NOW)
    assert parsed.components.pfz is True
    assert parsed.components.geospatial is True
    assert parsed.radius_km == 20.0


def test_parser_warns_and_defaults_time_window_when_location_missing() -> None:
    parsed = parse_query("What about tomorrow?", now=NOW)
    assert parsed.location is None
    assert any("latitude/longitude" in warning for warning in parsed.warnings)
    assert parsed.time_window.start == NOW.replace(day=13)


def test_parser_falls_back_to_general_briefing_when_no_keyword_matches() -> None:
    parsed = parse_query("13.05, 80.20", now=NOW)
    assert parsed.components.weather is True
    assert parsed.components.ocean is True
    assert parsed.components.pfz is True
    assert parsed.components.risk is True


def test_parser_flags_geofence_component_for_restricted_area_language() -> None:
    parsed = parse_query("Is 13.11, 80.31 a restricted marine protected area?", now=NOW)
    assert parsed.components.geofence is True
    assert parsed.location == GeoPoint(latitude=13.11, longitude=80.31)


def test_parser_does_not_flag_geofence_for_an_ordinary_weather_query() -> None:
    parsed = parse_query("What's the weather at 13.05, 80.20?", now=NOW)
    assert parsed.components.geofence is False


# ---------------------------------------------------------------------------
# Orchestrator-level tests (2+ query types)
# ---------------------------------------------------------------------------


def test_weather_only_query_routes_to_weather_component_only() -> None:
    weather_provider = SpyWeatherProvider(_weather_finding())
    ocean_provider = SpyOceanProvider(_ocean_conditions())
    pfz_provider = SpyPFZProvider([])
    orchestrator = _build_orchestrator(weather_provider, ocean_provider, pfz_provider)

    result = orchestrator.execute(
        OrchestratorQuery(text="What's the wind and rain forecast at 13.05, 80.20?", requested_at=NOW)
    )

    assert result.status == "success"
    assert result.weather is not None
    assert result.ocean is None
    assert result.pfz is None
    assert result.geospatial is None
    assert result.risk is None
    assert weather_provider.calls == 1
    assert ocean_provider.calls == 0
    assert pfz_provider.calls == 0


def test_fishing_zone_query_with_radius_routes_to_geospatial_component() -> None:
    weather_provider = SpyWeatherProvider(_weather_finding())
    ocean_provider = SpyOceanProvider(_ocean_conditions())
    near = _pfz_record("near", longitude=80.01, latitude=13.0)
    far = _pfz_record("far", longitude=82.0, latitude=15.0)
    pfz_provider = SpyPFZProvider([far, near])
    orchestrator = _build_orchestrator(weather_provider, ocean_provider, pfz_provider)

    result = orchestrator.execute(
        OrchestratorQuery(text="Find fishing zones within 20 km of 13.0, 80.0", requested_at=NOW)
    )

    assert result.status == "success"
    assert result.weather is None
    assert result.pfz is None
    assert result.geospatial is not None
    assert [pfz.pfz_id for pfz in result.geospatial.nearby_pfzs] == ["near"]
    assert result.geospatial.radius_km == 20.0
    assert weather_provider.calls == 0


def test_risk_query_reuses_weather_and_ocean_outputs_without_recomputing() -> None:
    weather_provider = SpyWeatherProvider(_weather_finding(wind_speed_knots=18, wave_height_m=2.0))
    ocean_provider = SpyOceanProvider(_ocean_conditions(sea_state="rough"))
    pfz_provider = SpyPFZProvider([_pfz_record("pfz-alpha", longitude=80.215, latitude=13.015)])
    orchestrator = _build_orchestrator(weather_provider, ocean_provider, pfz_provider)

    result = orchestrator.execute(
        OrchestratorQuery(text="Is it safe to go fishing at 13.015, 80.215 right now?", requested_at=NOW)
    )

    assert result.status == "success"
    assert result.weather is not None
    assert result.ocean is not None
    assert result.pfz is not None
    assert result.risk is not None
    # Weather and ocean each computed exactly once, even though both feed
    # into the risk assessment as well as their own result fields.
    assert weather_provider.calls == 1
    assert ocean_provider.calls == 1
    # The risk engine's inputs are literally the weather/ocean agents'
    # own outputs, not independently recomputed values.
    assert result.risk.reproducibility_inputs["weather"]["wind_speed_knots"] == 18
    assert result.risk.reproducibility_inputs["ocean"]["sea_state"] == "rough"
    assert result.risk.overall_score == 55 + 20  # wind + waves + rough sea state
    assert result.risk.category == "severe"
    assert result.evidence_recommendation is not None
    assert result.evidence_recommendation.recommendation == result.risk.recommendation
    assert result.evidence_recommendation.overall_risk_score == result.risk.overall_score


def test_general_query_without_keywords_runs_full_briefing() -> None:
    weather_provider = SpyWeatherProvider(_weather_finding())
    ocean_provider = SpyOceanProvider(_ocean_conditions())
    pfz_provider = SpyPFZProvider([_pfz_record("pfz-alpha", longitude=80.215, latitude=13.015)])
    orchestrator = _build_orchestrator(weather_provider, ocean_provider, pfz_provider)

    result = orchestrator.execute(OrchestratorQuery(text="13.015, 80.215", requested_at=NOW))

    assert result.status == "success"
    assert result.weather is not None
    assert result.ocean is not None
    assert result.pfz is not None
    assert result.risk is not None
    assert result.geospatial is None  # no radius mentioned


def test_missing_location_is_handled_safely_without_crashing() -> None:
    weather_provider = SpyWeatherProvider(_weather_finding())
    ocean_provider = SpyOceanProvider(_ocean_conditions())
    pfz_provider = SpyPFZProvider([])
    orchestrator = _build_orchestrator(weather_provider, ocean_provider, pfz_provider)

    result = orchestrator.execute(OrchestratorQuery(text="Is it safe to go fishing right now?", requested_at=NOW))

    assert result.status == "unavailable"
    assert result.weather is None
    assert result.ocean is None
    assert result.pfz is None
    assert result.risk is None
    assert weather_provider.calls == 0
    assert ocean_provider.calls == 0
    assert any("location" in warning.lower() for warning in result.warnings)


def test_orchestrator_is_stateless_across_calls() -> None:
    weather_provider = SpyWeatherProvider(_weather_finding())
    ocean_provider = SpyOceanProvider(_ocean_conditions())
    pfz_provider = SpyPFZProvider([])
    orchestrator = _build_orchestrator(weather_provider, ocean_provider, pfz_provider)

    first = orchestrator.execute(OrchestratorQuery(text="weather at 13.0, 80.0", requested_at=NOW))
    second = orchestrator.execute(OrchestratorQuery(text="Is it safe to go fishing right now?", requested_at=NOW))

    # The second, location-less call is unaffected by the first call's location.
    assert first.weather is not None
    assert second.weather is None
    assert second.status == "unavailable"
