from datetime import datetime, timedelta, timezone

from app.conversation import ConversationService
from app.domain import ConversationTurnRequest, GeoPoint
from app.orchestrator.agent import build_demo_orchestrator

NOW = datetime(2026, 9, 12, 6, tzinfo=timezone.utc)


def test_follow_up_reuses_location_and_selection_but_updates_explicit_time() -> None:
    service = ConversationService(build_demo_orchestrator())
    first = service.execute(
        ConversationTurnRequest(
            conversation_id="trip-1",
            text="Is it safe to go fishing at 13.015, 80.215?",
            requested_at=NOW,
            selected_pfz_id="pfz-alpha",
            selected_area=GeoPoint(latitude=13.015, longitude=80.215),
        )
    )
    follow_up = service.execute(
        ConversationTurnRequest(conversation_id="trip-1", text="Find a safer zone tomorrow", requested_at=NOW)
    )

    assert first.context.location == GeoPoint(latitude=13.015, longitude=80.215)
    assert follow_up.context.location == first.context.location
    assert follow_up.context.selected_pfz_id == "pfz-alpha"
    assert follow_up.context.selected_area == GeoPoint(latitude=13.015, longitude=80.215)
    assert follow_up.context.time_window.start == NOW + timedelta(days=1)
    assert follow_up.result.parsed_query.location == first.context.location
    assert follow_up.result.geospatial is not None


def test_follow_up_does_not_invent_location_when_context_never_had_one() -> None:
    service = ConversationService(build_demo_orchestrator())

    response = service.execute(
        ConversationTurnRequest(conversation_id="empty", text="What about tomorrow?", requested_at=NOW)
    )

    assert response.context.location is None
    assert response.result.parsed_query.location is None
    assert response.result.status == "unavailable"
