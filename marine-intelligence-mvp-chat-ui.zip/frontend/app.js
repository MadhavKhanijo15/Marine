/* Poseidon — minimal chat UI over the existing conversation/orchestrator API.
 * This file renders only what the backend returns: no marine calculation,
 * routing, or geofencing logic lives here. */

(() => {
  "use strict";

  // ---------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------
  const conversationStorageKey = "marine-intelligence-conversation-id";
  let conversationId = sessionStorage.getItem(conversationStorageKey) || crypto.randomUUID();
  sessionStorage.setItem(conversationStorageKey, conversationId);

  let selectedPfzId = null;
  let mapInstance = null;
  let mapLayers = [];
  let lastResultWithLocation = null;

  // ---------------------------------------------------------------------
  // DOM references
  // ---------------------------------------------------------------------
  const messagesEl = document.querySelector("#messages");
  const composerEl = document.querySelector("#composer");
  const questionEl = document.querySelector("#question");
  const sendBtn = document.querySelector("#send");
  const locateBtn = document.querySelector("#locate");
  const newChatBtn = document.querySelector("#new-chat");
  const toggleMapBtn = document.querySelector("#toggle-map");
  const closeMapBtn = document.querySelector("#close-map");
  const mapPanelEl = document.querySelector("#map-panel");
  const mapScrimEl = document.querySelector("#map-scrim");
  const mapCaptionEl = document.querySelector("#map-caption");
  const selectedChipEl = document.querySelector("#selected-pfz-chip");
  const appEl = document.querySelector(".app");

  // ---------------------------------------------------------------------
  // Small formatting helpers
  // ---------------------------------------------------------------------
  const WEATHER_LABELS = {
    wind_speed_knots: "Wind",
    wave_height_m: "Wave height",
    rainfall_mm: "Rainfall",
    visibility_km: "Visibility",
    thunderstorm_probability: "Storm chance",
  };
  const OCEAN_LABELS = {
    sea_surface_temperature_c: "Sea surface temp",
    chlorophyll_mg_m3: "Chlorophyll",
    wave_height_m: "Wave height",
    wave_period_s: "Wave period",
    sea_state: "Sea state",
  };
  const UNITS = {
    wind_speed_knots: " kn",
    wave_height_m: " m",
    rainfall_mm: " mm",
    visibility_km: " km",
    sea_surface_temperature_c: " °C",
    chlorophyll_mg_m3: " mg/m³",
    wave_period_s: " s",
  };
  const RECOMMENDATION_LABELS = {
    go: "Go",
    proceed_with_caution: "Proceed with caution",
    postpone: "Postpone",
    do_not_go: "Do not go",
  };

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>'"]/g, (ch) => (
      { "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[ch]
    ));
  }

  function formatMetric(field, value, unitsMap) {
    if (field === "thunderstorm_probability" && value !== null && value !== undefined) {
      return `${Math.round(value * 100)}%`;
    }
    if (typeof value === "number" && !Number.isInteger(value)) {
      value = Math.round(value * 100) / 100;
    }
    return `${value}${(unitsMap && unitsMap[field]) || ""}`;
  }

  function el(tag, className, html) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (html !== undefined) node.innerHTML = html;
    return node;
  }

  function scrollToBottom(smooth = true) {
    messagesEl.scrollTo({ top: messagesEl.scrollHeight, behavior: smooth ? "smooth" : "auto" });
  }

  // ---------------------------------------------------------------------
  // Empty state / welcome
  // ---------------------------------------------------------------------
  const SUGGESTIONS = [
    { label: "Use my current location", action: "locate" },
    { label: "Is it safe to go out today?", action: "text", text: "Is it safe to go out at 13.015, 80.215?" },
    { label: "Find fishing zones nearby", action: "text", text: "Find fishing zones near 13.015, 80.215" },
    { label: "Any restricted zones here?", action: "text", text: "Are there restricted zones near 13.015, 80.215?" },
  ];

  function renderEmptyState() {
    const wrap = el("div", "empty-state");
    wrap.innerHTML = `
      <span class="brand-mark" aria-hidden="true" style="display:grid;place-items:center;">
        <svg viewBox="0 0 24 24" width="22" height="22" fill="none">
          <path d="M2 17c1.8 1.3 3.6 1.3 5.4 0 1.8-1.3 3.6-1.3 5.4 0 1.8 1.3 3.6 1.3 5.4 0 1.8-1.3 3.6-1.3 5.4 0" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/>
          <path d="M12 3v9M9 6.5l3-3.5 3 3.5" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
      </span>
      <h1>Where are you heading out today?</h1>
      <p>Ask about weather, sea conditions, fishing zones, or safety for any coordinate — Poseidon pulls the answer from live agent data and shows it on the map.</p>
    `;
    const chips = el("div", "suggestions");
    SUGGESTIONS.forEach((s) => {
      const chip = el("button", "suggestion-chip", escapeHtml(s.label));
      chip.type = "button";
      chip.addEventListener("click", () => {
        if (s.action === "locate") requestLocation();
        else submitConversationTurn(s.text);
      });
      chips.appendChild(chip);
    });
    wrap.appendChild(chips);
    messagesEl.appendChild(wrap);
  }

  function clearEmptyState() {
    const existing = messagesEl.querySelector(".empty-state");
    if (existing) existing.remove();
  }

  // ---------------------------------------------------------------------
  // Message rendering
  // ---------------------------------------------------------------------
  function addUserMessage(text) {
    clearEmptyState();
    const row = el("div", "row user");
    const col = el("div", "bubble-col");
    col.appendChild(el("div", "bubble", escapeHtml(text)));
    row.appendChild(col);
    messagesEl.appendChild(row);
    scrollToBottom();
  }

  function addLoadingMessage() {
    const row = el("div", "row assistant");
    row.dataset.loading = "true";
    row.appendChild(el("div", "avatar", waveIconSvg()));
    const col = el("div", "bubble-col");
    const bubble = el("div", "bubble typing");
    bubble.innerHTML = `Analyzing marine data<span class="typing-dots"><span></span><span></span><span></span></span>`;
    col.appendChild(bubble);
    row.appendChild(col);
    messagesEl.appendChild(row);
    scrollToBottom();
    return row;
  }

  function waveIconSvg() {
    return `<svg viewBox="0 0 24 24" width="15" height="15" fill="none"><path d="M2 17c1.8 1.3 3.6 1.3 5.4 0 1.8-1.3 3.6-1.3 5.4 0 1.8 1.3 3.6 1.3 5.4 0 1.8-1.3 3.6-1.3 5.4 0" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>`;
  }

  function riskClassFor(result) {
    const rec = result.evidence_recommendation;
    return (rec && rec.risk_category) || (result.risk && result.risk.category) || "";
  }

  function buildHeadline(result) {
    const rec = result.evidence_recommendation;
    if (rec && rec.recommendation) {
      const label = RECOMMENDATION_LABELS[rec.recommendation] || rec.recommendation;
      const bubble = el("div", "bubble headline");
      bubble.innerHTML = `
        <span class="status-dot ${escapeHtml(rec.recommendation)}"></span>
        <span>${escapeHtml(label)} · ${escapeHtml((rec.risk_category || "").replace(/^./, (c) => c.toUpperCase()))} risk</span>
        <span class="score-tag">${rec.overall_risk_score ?? "–"}/100</span>
      `;
      return bubble;
    }

    // No risk assessment was requested/available — give a plain, honest summary line.
    const hasAnyData = result.weather || result.ocean || result.pfz || result.geospatial;
    const text = hasAnyData
      ? "Here's what I found for that location."
      : "I couldn't find enough information to answer that yet.";
    return el("div", "bubble", escapeHtml(text));
  }

  function buildReasonsList(result) {
    const rec = result.evidence_recommendation;
    if (!rec || !rec.key_reasons || rec.key_reasons.length === 0) return null;
    const list = el("ul", "reasons");
    rec.key_reasons.slice(0, 5).forEach((reason) => {
      const li = document.createElement("li");
      li.className = `sev-${reason.severity}`;
      li.textContent = reason.summary;
      list.appendChild(li);
    });
    return list;
  }

  function buildRiskCard(result) {
    if (!result.risk) return null;
    const category = result.risk.category;
    const card = el("div", `card risk-card ${category}`);
    card.innerHTML = `<h3>Risk</h3>`;
    const dl = el("dl", "metric-grid");
    dl.innerHTML = `
      <dt>Score</dt><dd>${result.risk.overall_score}/100</dd>
      <dt>Category</dt><dd>${escapeHtml(category)}</dd>
      <dt>Recommendation</dt><dd>${escapeHtml(RECOMMENDATION_LABELS[result.risk.recommendation] || result.risk.recommendation)}</dd>
    `;
    card.appendChild(dl);
    return card;
  }

  function buildMetricsCard(title, data, fields, labels) {
    if (!data) return null;
    const present = fields.filter((f) => data[f] !== null && data[f] !== undefined && data[f] !== "");
    if (present.length === 0) return null;
    const card = el("div", "card");
    card.innerHTML = `<h3>${escapeHtml(title)}</h3>`;
    const dl = el("dl", "metric-grid");
    dl.innerHTML = present
      .map((f) => `<dt>${escapeHtml(labels[f])}</dt><dd>${escapeHtml(formatMetric(f, data[f], UNITS))}</dd>`)
      .join("");
    card.appendChild(dl);
    return card;
  }

  function pfzListFrom(result) {
    if (result.geospatial && result.geospatial.nearby_pfzs) return result.geospatial.nearby_pfzs;
    if (result.pfz && result.pfz.nearby_pfzs) return result.pfz.nearby_pfzs;
    return [];
  }

  function buildPfzCard(result) {
    const pfzs = pfzListFrom(result);
    if (pfzs.length === 0) return null;
    const card = el("div", "card");
    card.innerHTML = `<h3>Nearby fishing zones</h3>`;
    const list = el("ul", "pfz-list");
    pfzs.slice(0, 6).forEach((pfz) => {
      const item = el("li", "pfz-item" + (pfz.pfz_id === selectedPfzId ? " selected" : ""));
      item.dataset.pfzId = pfz.pfz_id;
      item.innerHTML = `
        <span><span class="pfz-name">${escapeHtml(pfz.pfz_id)}</span> · <span class="pfz-dist">${escapeHtml(formatMetric("distance", pfz.distance_km, {}))} km</span></span>
      `;
      const selectBtn = el("button", "pfz-select" + (pfz.pfz_id === selectedPfzId ? " is-selected" : ""), pfz.pfz_id === selectedPfzId ? "Selected" : "Select");
      selectBtn.type = "button";
      selectBtn.addEventListener("click", () => {
        selectedPfzId = pfz.pfz_id === selectedPfzId ? null : pfz.pfz_id;
        updateSelectedChip();
        refreshPfzSelectionUi();
      });
      item.appendChild(selectBtn);
      list.appendChild(item);
    });
    card.appendChild(list);
    return card;
  }

  function refreshPfzSelectionUi() {
    document.querySelectorAll(".pfz-item").forEach((item) => {
      const isSelected = item.dataset.pfzId === selectedPfzId;
      item.classList.toggle("selected", isSelected);
      const btn = item.querySelector(".pfz-select");
      if (btn) {
        btn.classList.toggle("is-selected", isSelected);
        btn.textContent = isSelected ? "Selected" : "Select";
      }
    });
  }

  function updateSelectedChip() {
    if (selectedPfzId) {
      selectedChipEl.hidden = false;
      selectedChipEl.textContent = `Selected: ${selectedPfzId}`;
    } else {
      selectedChipEl.hidden = true;
      selectedChipEl.textContent = "";
    }
  }

  function buildBanners(result) {
    const banners = [];
    const rec = result.evidence_recommendation;
    const warnings = (rec ? rec.warnings : result.warnings) || [];
    // Geofence violations are already folded into `warnings` by the backend;
    // surface them distinctly so they read as an alert, not a footnote.
    const violationWarnings = warnings.filter((w) => /restrict|protected|exclusion|no-fishing|no fishing/i.test(w));
    const otherWarnings = warnings.filter((w) => !violationWarnings.includes(w));

    violationWarnings.forEach((message) => {
      banners.push(el("div", "banner danger", escapeHtml(message)));
    });
    if (otherWarnings.length > 0) {
      banners.push(el("div", "banner info", escapeHtml(otherWarnings.join(" "))));
    }
    return banners;
  }

  function resultHasMappable(result) {
    return Boolean(result.parsed_query && result.parsed_query.location) || pfzListFrom(result).length > 0;
  }

  function buildViewOnMapButton(result) {
    if (!resultHasMappable(result)) return null;
    const btn = el(
      "button",
      "view-map-btn",
      `<svg viewBox="0 0 24 24" width="13" height="13" fill="none"><path d="M9 4 3 6.5v13L9 17m0-13 6 2m-6-2v13m6-11 6-2.5v13L15 17m0-13v13" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg> View on map`
    );
    btn.type = "button";
    btn.addEventListener("click", () => openMapFor(result));
    return btn;
  }

  function addAssistantMessage(result) {
    clearEmptyState();
    const row = el("div", "row assistant");
    row.appendChild(el("div", "avatar", waveIconSvg()));
    const col = el("div", "bubble-col");

    col.appendChild(buildHeadline(result));

    const reasons = buildReasonsList(result);
    if (reasons) col.appendChild(reasons);

    buildBanners(result).forEach((b) => col.appendChild(b));

    const cards = [
      buildRiskCard(result),
      buildMetricsCard("Weather", result.weather?.findings?.[0], Object.keys(WEATHER_LABELS), WEATHER_LABELS),
      buildMetricsCard("Ocean", result.ocean?.conditions, Object.keys(OCEAN_LABELS), OCEAN_LABELS),
      buildPfzCard(result),
    ].filter(Boolean);

    if (cards.length > 0) {
      const cardRow = el("div", "card-row");
      cards.forEach((c) => cardRow.appendChild(c));
      col.appendChild(cardRow);
    }

    const mapBtn = buildViewOnMapButton(result);
    if (mapBtn) col.appendChild(mapBtn);

    row.appendChild(col);
    messagesEl.appendChild(row);
    scrollToBottom();

    if (resultHasMappable(result)) {
      lastResultWithLocation = result;
      if (mapPanelEl.classList.contains("open")) renderMapForResult(result);
    }
  }

  function addErrorMessage(message) {
    clearEmptyState();
    const row = el("div", "row assistant");
    row.appendChild(el("div", "avatar", waveIconSvg()));
    const col = el("div", "bubble-col");
    col.appendChild(el("div", "bubble", escapeHtml(message)));
    row.appendChild(col);
    messagesEl.appendChild(row);
    scrollToBottom();
  }

  // ---------------------------------------------------------------------
  // Map panel (Leaflet) — a renderer only; all data comes from the backend.
  // ---------------------------------------------------------------------
  function ensureMap() {
    if (mapInstance) return mapInstance;
    mapInstance = L.map("map", { zoomControl: true }).setView([0, 0], 2);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 18,
      attribution: "&copy; OpenStreetMap contributors",
    }).addTo(mapInstance);
    return mapInstance;
  }

  function clearMapLayers() {
    mapLayers.forEach((layer) => mapInstance.removeLayer(layer));
    mapLayers = [];
  }

  function renderMapForResult(result) {
    const map = ensureMap();
    clearMapLayers();

    const bounds = [];
    const location = result.parsed_query && result.parsed_query.location;
    if (location) {
      const marker = L.circleMarker([location.latitude, location.longitude], {
        radius: 8,
        color: "#ffffff",
        fillColor: "#34c3b6",
        fillOpacity: 1,
        weight: 2,
      }).bindPopup("Queried location");
      marker.addTo(map);
      mapLayers.push(marker);
      bounds.push([location.latitude, location.longitude]);
    }

    pfzListFrom(result).forEach((pfz) => {
      const marker = L.marker([pfz.coordinates.latitude, pfz.coordinates.longitude]).bindPopup(
        `<strong>${escapeHtml(pfz.pfz_id)}</strong><br>${escapeHtml(formatMetric("distance", pfz.distance_km, {}))} km away`
      );
      marker.on("click", () => {
        selectedPfzId = pfz.pfz_id;
        updateSelectedChip();
        refreshPfzSelectionUi();
      });
      marker.addTo(map);
      mapLayers.push(marker);
      bounds.push([pfz.coordinates.latitude, pfz.coordinates.longitude]);
    });

    if (bounds.length === 1) {
      map.setView(bounds[0], 9);
    } else if (bounds.length > 1) {
      map.fitBounds(bounds, { padding: [40, 40] });
    }

    const count = pfzListFrom(result).length;
    mapCaptionEl.textContent = location
      ? `${location.latitude.toFixed(3)}, ${location.longitude.toFixed(3)}${count ? ` · ${count} fishing zone${count === 1 ? "" : "s"} shown` : ""}`
      : `${count} fishing zone${count === 1 ? "" : "s"} shown`;

    setTimeout(() => map.invalidateSize(), 250);
  }

  function openMapFor(result) {
    openMapPanel();
    renderMapForResult(result);
  }

  function openMapPanel() {
    mapPanelEl.classList.add("open");
    appEl.classList.add("map-open");
    toggleMapBtn.setAttribute("aria-expanded", "true");
    if (window.matchMedia("(max-width: 980px)").matches) mapScrimEl.hidden = false;
    ensureMap();
    setTimeout(() => mapInstance.invalidateSize(), 300);
    if (lastResultWithLocation) renderMapForResult(lastResultWithLocation);
  }

  function closeMapPanel() {
    mapPanelEl.classList.remove("open");
    appEl.classList.remove("map-open");
    toggleMapBtn.setAttribute("aria-expanded", "false");
    mapScrimEl.hidden = true;
  }

  toggleMapBtn.addEventListener("click", () => {
    if (mapPanelEl.classList.contains("open")) closeMapPanel();
    else openMapPanel();
  });
  closeMapBtn.addEventListener("click", closeMapPanel);
  mapScrimEl.addEventListener("click", closeMapPanel);

  // ---------------------------------------------------------------------
  // Networking
  // ---------------------------------------------------------------------
  function setBusy(isBusy) {
    sendBtn.disabled = isBusy;
    questionEl.disabled = isBusy;
    locateBtn.disabled = isBusy;
  }

  async function submitConversationTurn(text) {
    if (!text || !text.trim()) return;
    addUserMessage(text);
    setBusy(true);
    const loadingRow = addLoadingMessage();

    try {
      const body = { conversation_id: conversationId, text };
      if (selectedPfzId) body.selected_pfz_id = selectedPfzId;
      const response = await fetch("/api/conversations/turn", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      if (!response.ok) {
        let detail = `Request failed (${response.status})`;
        try {
          const problem = await response.json();
          if (problem && problem.detail) detail = JSON.stringify(problem.detail);
        } catch (_) {
          /* ignore parse failure, use default detail */
        }
        throw new Error(detail);
      }
      const turn = await response.json();
      loadingRow.remove();
      addAssistantMessage(turn.result);
    } catch (error) {
      loadingRow.remove();
      addErrorMessage(`Something went wrong: ${error.message}`);
    } finally {
      setBusy(false);
      questionEl.focus();
    }
  }

  function requestLocation() {
    if (!navigator.geolocation) {
      addErrorMessage("Browser location is not available here.");
      return;
    }
    setBusy(true);
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => {
        setBusy(false);
        submitConversationTurn(`marine briefing at ${coords.latitude}, ${coords.longitude}`);
      },
      (error) => {
        setBusy(false);
        addErrorMessage(`Location unavailable: ${error.message}`);
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 }
    );
  }

  // ---------------------------------------------------------------------
  // Composer wiring
  // ---------------------------------------------------------------------
  function autoGrow() {
    questionEl.style.height = "auto";
    questionEl.style.height = `${Math.min(questionEl.scrollHeight, 140)}px`;
  }
  questionEl.addEventListener("input", autoGrow);
  questionEl.addEventListener("keydown", (event) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      composerEl.requestSubmit();
    }
  });

  composerEl.addEventListener("submit", (event) => {
    event.preventDefault();
    const text = questionEl.value.trim();
    if (!text) return;
    questionEl.value = "";
    autoGrow();
    submitConversationTurn(text);
  });

  locateBtn.addEventListener("click", requestLocation);

  newChatBtn.addEventListener("click", () => {
    conversationId = crypto.randomUUID();
    sessionStorage.setItem(conversationStorageKey, conversationId);
    selectedPfzId = null;
    lastResultWithLocation = null;
    updateSelectedChip();
    messagesEl.innerHTML = "";
    renderEmptyState();
    if (mapInstance) clearMapLayers();
    mapCaptionEl.textContent = "Ask about a location to see it here.";
    closeMapPanel();
    questionEl.focus();
  });

  // ---------------------------------------------------------------------
  // Boot
  // ---------------------------------------------------------------------
  renderEmptyState();
})();
