"""Typed domain contracts shared by agents, providers, and deterministic services."""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator


class Activity(str, Enum):
    FISHING = "fishing"


class DataStatus(str, Enum):
    SUCCESS = "success"
    PARTIAL = "partial"
    UNAVAILABLE = "unavailable"


class RiskCategory(str, Enum):
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    SEVERE = "severe"


class Recommendation(str, Enum):
    GO = "go"
    PROCEED_WITH_CAUTION = "proceed_with_caution"
    POSTPONE = "postpone"
    DO_NOT_GO = "do_not_go"


class GeoPoint(BaseModel):
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)


class TimeWindow(BaseModel):
    start: datetime
    end: datetime
    timezone: str = "UTC"

    @field_validator("end")
    @classmethod
    def end_must_follow_start(cls, end: datetime, info: Any) -> datetime:
        start = info.data.get("start")
        if start is not None and end <= start:
            raise ValueError("end must be after start")
        return end


class EvidenceItem(BaseModel):
    id: str
    source_type: str
    source_name: str
    summary: str
    observed_at: datetime | None = None
    valid_for: TimeWindow | None = None
    attributes: dict[str, Any] = Field(default_factory=dict)
    confidence: str = "high"


class WeatherSourceMetadata(BaseModel):
    """Provenance for a normalized weather observation."""

    provider: str
    dataset: str
    retrieved_at: datetime
    source_url: str | None = None


class WeatherQuery(BaseModel):
    location: GeoPoint
    time_window: TimeWindow
    activity: Activity = Activity.FISHING


class WeatherFinding(BaseModel):
    location: GeoPoint
    time_window: TimeWindow
    observed_at: datetime
    source: WeatherSourceMetadata
    wind_speed_knots: float | None = Field(default=None, ge=0)
    wave_height_m: float | None = Field(default=None, ge=0)
    rainfall_mm: float | None = Field(default=None, ge=0)
    visibility_km: float | None = Field(default=None, ge=0)
    thunderstorm_probability: float | None = Field(default=None, ge=0, le=1)
    alerts: list[str] = Field(default_factory=list)
    evidence: list[EvidenceItem] = Field(default_factory=list)


class WeatherAgentResult(BaseModel):
    status: DataStatus
    findings: list[WeatherFinding] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    evidence: list[EvidenceItem] = Field(default_factory=list)


class OceanSourceMetadata(BaseModel):
    """Provenance for a normalized ocean observation."""

    provider: str
    dataset: str
    retrieved_at: datetime
    source_url: str | None = None


class OceanQuery(BaseModel):
    """Ocean observation request constrained to a place and time window."""

    location: GeoPoint
    time_window: TimeWindow


class OceanConditions(BaseModel):
    """Validated ocean parameters; optional fields reflect provider availability."""

    location: GeoPoint
    observed_at: datetime
    source: OceanSourceMetadata
    sea_surface_temperature_c: float = Field(ge=-2, le=50)
    chlorophyll_mg_m3: float = Field(ge=0)
    wave_height_m: float = Field(ge=0)
    wave_period_s: float | None = Field(default=None, gt=0)
    sea_state: str | None = None


class OceanAgentResult(BaseModel):
    status: DataStatus
    conditions: OceanConditions


class PFZSourceMetadata(BaseModel):
    """Provenance for a potential fishing-zone observation."""

    provider: str
    dataset: str
    retrieved_at: datetime
    source_url: str | None = None


class PFZSearchQuery(BaseModel):
    """Find PFZ observations near this latitude/longitude at an optional time."""

    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    requested_at: datetime | None = None

    @property
    def location(self) -> GeoPoint:
        return GeoPoint(latitude=self.latitude, longitude=self.longitude)


class PFZDataRecord(BaseModel):
    """Provider-level PFZ data before distance is calculated."""

    pfz_id: str
    geometry: dict[str, Any]
    observed_at: datetime
    source: PFZSourceMetadata
    sea_surface_temperature_c: float | None = Field(default=None, ge=-2, le=50)
    chlorophyll_mg_m3: float | None = Field(default=None, ge=0)


class NearbyPFZ(BaseModel):
    """A PFZ record enriched only with deterministic distance and centroid coordinates."""

    pfz_id: str
    coordinates: GeoPoint
    distance_km: float = Field(ge=0)
    observed_at: datetime
    source: PFZSourceMetadata
    sea_surface_temperature_c: float | None = Field(default=None, ge=-2, le=50)
    chlorophyll_mg_m3: float | None = Field(default=None, ge=0)


class PFZFishingAgentResult(BaseModel):
    status: DataStatus
    nearby_pfzs: list[NearbyPFZ]


class GeospatialPFZQuery(PFZSearchQuery):
    """Find PFZ observations within a fixed radius of a validated lat/lon."""

    radius_km: float = Field(gt=0)


class GeospatialAgentResult(BaseModel):
    status: DataStatus
    origin: GeoPoint
    radius_km: float
    nearby_pfzs: list[NearbyPFZ] = Field(default_factory=list)


class FishingZone(BaseModel):
    model_config = ConfigDict(extra="forbid")

    zone_id: str
    geometry: dict[str, Any]
    validity_window: TimeWindow
    suitability_score: float = Field(ge=0, le=100)
    species_hint: str | None = None
    ocean_conditions: dict[str, Any] = Field(default_factory=dict)
    evidence: list[EvidenceItem] = Field(default_factory=list)


class PFZQuery(BaseModel):
    departure_point: GeoPoint
    time_window: TimeWindow
    activity: Activity = Activity.FISHING


class PFZAgentResult(BaseModel):
    status: DataStatus
    candidate_zones: list[FishingZone] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    evidence: list[EvidenceItem] = Field(default_factory=list)


class ZoneRestrictionType(str, Enum):
    MARINE_PROTECTED_AREA = "marine_protected_area"
    RESTRICTED_ZONE = "restricted_zone"
    NO_FISHING_ZONE = "no_fishing_zone"
    NAVAL_EXCLUSION_ZONE = "naval_exclusion_zone"


class RestrictedZone(BaseModel):
    """A protected or restricted marine area sourced from seeded GeoJSON.

    Geometry is kept as a raw GeoJSON dict here (as with ``FishingZone``); it
    is only ever parsed into a Shapely shape inside ``app.geospatial.service``.
    """

    zone_id: str
    name: str
    restriction_type: ZoneRestrictionType
    geometry: dict[str, Any]
    description: str | None = None
    authority: str | None = None


class GeofenceQuery(BaseModel):
    """Check a single validated point against known restricted/protected areas."""

    location: GeoPoint


class GeofenceViolation(BaseModel):
    """One restricted zone a checked point or geometry was found inside/overlapping."""

    zone_id: str
    zone_name: str
    restriction_type: ZoneRestrictionType
    message: str
    authority: str | None = None


class GeofenceCheckResult(BaseModel):
    """Restricted-zone assessment for a single point (e.g. a user location)."""

    status: DataStatus
    location: GeoPoint
    inside_restricted_zone: bool
    violations: list[GeofenceViolation] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class PFZGeometryInput(BaseModel):
    """A named geometry to check against restricted zones (e.g. a PFZ polygon)."""

    pfz_id: str
    geometry: dict[str, Any]


class PFZGeofenceAssessment(BaseModel):
    """Restricted-zone assessment for one PFZ/candidate-zone geometry."""

    pfz_id: str
    inside_restricted_zone: bool
    violations: list[GeofenceViolation] = Field(default_factory=list)


class GeofenceBatchQuery(BaseModel):
    """Check an optional location and/or a set of named PFZ geometries in one pass."""

    location: GeoPoint | None = None
    pfzs: list[PFZGeometryInput] = Field(default_factory=list)


class GeofenceAgentResult(BaseModel):
    status: DataStatus
    location_assessment: GeofenceCheckResult | None = None
    pfz_assessments: list[PFZGeofenceAssessment] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class RouteQuery(BaseModel):
    """A start point plus an explicit destination point or a selected PFZ id.

    Exactly one of ``destination`` / ``destination_pfz_id`` must be supplied;
    ``time_window`` is required (as with ``WeatherQuery``/``OceanQuery``) so
    any risk assessment uses an explicit, caller-supplied window rather than
    a default invented inside the routing module.
    """

    start: GeoPoint
    destination: GeoPoint | None = None
    destination_pfz_id: str | None = None
    time_window: TimeWindow

    @model_validator(mode="after")
    def _exactly_one_destination(self) -> "RouteQuery":
        if (self.destination is None) == (self.destination_pfz_id is None):
            raise ValueError("Provide exactly one of destination or destination_pfz_id")
        return self


class RouteResult(BaseModel):
    """Deterministic MVP route: coordinates, distance, restricted-zone status, and risk.

    MVP only -- not professional maritime navigation. ``risk_level``/
    ``risk_score`` are ``None`` whenever risk inputs were not supplied or
    unavailable; they are never estimated or invented.
    """

    status: DataStatus
    start: GeoPoint
    destination: GeoPoint
    destination_pfz_id: str | None = None
    route: list[GeoPoint]
    distance_km: float = Field(ge=0)
    detoured: bool
    clear_of_restricted_zones: bool
    geofence_violations: list[GeofenceViolation] = Field(default_factory=list)
    risk_level: RiskCategory | None = None
    risk_score: int | None = Field(default=None, ge=0, le=100)
    reasons: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    calculation_version: str


class GeoSearchRequest(BaseModel):
    origin: GeoPoint
    candidate_zones: list[FishingZone]
    hazard_features: list[dict[str, Any]] = Field(default_factory=list)
    permitted_area: dict[str, Any] | None = None
    max_distance_km: float | None = Field(default=None, gt=0)


class ZoneSpatialAssessment(BaseModel):
    zone_id: str
    centroid: GeoPoint
    distance_from_origin_km: float = Field(ge=0)
    intersects_hazard: bool
    inside_permitted_area: bool
    excluded: bool
    exclusion_reasons: list[str] = Field(default_factory=list)
    route_geometry: dict[str, Any] | None = None


class GeoSearchResult(BaseModel):
    ranked_candidates: list[ZoneSpatialAssessment]
    calculation_version: str


class VesselProfile(BaseModel):
    vessel_class: str = "small_fishing_vessel"
    max_comfortable_wave_height_m: float = Field(default=1.5, gt=0)
    max_comfortable_wind_knots: float = Field(default=15, gt=0)


class RiskAssessmentInput(BaseModel):
    weather: WeatherFinding
    ocean: OceanConditions | None = None
    vessel_profile: VesselProfile = Field(default_factory=VesselProfile)
    spatial_assessment: ZoneSpatialAssessment | None = None
    policy_version: str = "mvp-1"


class RiskFactor(BaseModel):
    id: str
    measured_value: float | bool | str | None
    threshold: float | str
    contribution_points: int = Field(ge=0)
    severity: RiskCategory
    data_available: bool = True
    reason_code: str
    rationale: str


class RiskAssessmentResult(BaseModel):
    overall_score: int = Field(ge=0, le=100)
    category: RiskCategory
    recommendation: Recommendation
    factors: list[RiskFactor]
    reason_codes: list[str] = Field(default_factory=list)
    policy_version: str
    disclaimer: str = (
        "Demo heuristic thresholds only; not an official maritime safety standard."
    )
    reproducibility_inputs: dict[str, Any]


class QueryComponents(BaseModel):
    """Which specialist components a parsed query determined it needs."""

    weather: bool = False
    ocean: bool = False
    pfz: bool = False
    geospatial: bool = False
    risk: bool = False
    geofence: bool = False


class ParsedQuery(BaseModel):
    """Deterministic, rule-based interpretation of a natural-language marine query.

    Produced by keyword and regex matching only -- there is no LLM in this
    path, so the same text always parses the same way.
    """

    raw_text: str
    location: GeoPoint | None = None
    radius_km: float | None = None
    time_window: TimeWindow
    time_window_explicit: bool = False
    selected_pfz_id: str | None = None
    components: QueryComponents
    warnings: list[str] = Field(default_factory=list)


class ConversationContext(BaseModel):
    """The limited, explicit state retained for one in-process conversation."""

    location: GeoPoint | None = None
    time_window: TimeWindow | None = None
    selected_pfz_id: str | None = None
    selected_area: GeoPoint | None = None


class OrchestratorQuery(BaseModel):
    """A query with optional, already-resolved conversation context."""

    text: str
    requested_at: datetime | None = None
    context: ConversationContext | None = None


class RecommendationSource(BaseModel):
    """Verbatim provenance carried into the frontend recommendation payload."""

    source_type: str
    source_name: str
    provider: str | None = None
    dataset: str | None = None
    source_url: str | None = None
    observed_at: datetime | None = None
    retrieved_at: datetime | None = None
    valid_for: TimeWindow | None = None


class RecommendationValue(BaseModel):
    """A returned value and the provenance/timestamp that make it explainable."""

    field: str
    value: float | bool | str
    source: RecommendationSource | None = None


class RecommendationReason(BaseModel):
    """A decision reason copied from the deterministic risk assessment."""

    code: str
    summary: str
    severity: RiskCategory
    contribution_points: int = Field(ge=0)
    measured_value: float | bool | str | None = None
    threshold: float | str | None = None


class MissingCriticalData(BaseModel):
    """A field the upstream agents explicitly reported as unavailable."""

    field: str
    reason: str | None = None
    reason_code: str | None = None


class EvidenceRecommendation(BaseModel):
    """Frontend-ready decision view built only from an ``OrchestratorResult``."""

    recommendation: Recommendation | None = None
    risk_category: RiskCategory | None = None
    overall_risk_score: int | None = Field(default=None, ge=0, le=100)
    key_reasons: list[RecommendationReason] = Field(default_factory=list)
    relevant_values: list[RecommendationValue] = Field(default_factory=list)
    sources: list[RecommendationSource] = Field(default_factory=list)
    missing_critical_data: list[MissingCriticalData] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)


class OrchestratorResult(BaseModel):
    status: DataStatus
    parsed_query: ParsedQuery
    weather: WeatherAgentResult | None = None
    ocean: OceanAgentResult | None = None
    pfz: PFZFishingAgentResult | None = None
    geospatial: GeospatialAgentResult | None = None
    risk: RiskAssessmentResult | None = None
    geofence: GeofenceCheckResult | None = None
    evidence_recommendation: EvidenceRecommendation | None = None
    resolved_context: ConversationContext | None = None
    warnings: list[str] = Field(default_factory=list)


class ConversationTurnRequest(BaseModel):
    """One user turn. Only explicitly supplied fields can alter stored context."""

    conversation_id: str = Field(min_length=1, max_length=200)
    text: str = Field(min_length=1)
    requested_at: datetime | None = None
    selected_pfz_id: str | None = None
    selected_area: GeoPoint | None = None


class ConversationTurnResult(BaseModel):
    conversation_id: str
    context: ConversationContext
    result: OrchestratorResult
