"""Deterministic geospatial operations."""

