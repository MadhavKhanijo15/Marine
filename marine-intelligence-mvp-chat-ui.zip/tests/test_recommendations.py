from datetime import datetime, timezone

from app.domain import (
    DataStatus,
    GeoPoint,
    OceanAgentResult,
    OceanConditions,
    OceanSourceMetadata,
    OrchestratorResult,
    ParsedQuery,
    QueryComponents,
    Recommendation,
    RiskAssessmentResult,
    RiskCategory,
    RiskFactor,
    TimeWindow,
    WeatherAgentResult,
    WeatherFinding,
    WeatherSourceMetadata,
)
from app.recommendations import EvidenceRecommendationService

NOW = datetime(2026, 9, 12, 6, tzinfo=timezone.utc)
WINDOW = TimeWindow(start=NOW, end=NOW.replace(hour=12))


def _result(*, risk: RiskAssessmentResult | None) -> OrchestratorResult:
    weather_source = WeatherSourceMetadata(provider="weather-provider", dataset="forecast-v1", retrieved_at=NOW)
    ocean_source = OceanSourceMetadata(provider="ocean-provider", dataset="ocean-v1", retrieved_at=NOW)
    weather = WeatherFinding(
        location=GeoPoint(latitude=13.0, longitude=80.0), time_window=WINDOW, observed_at=NOW,
        source=weather_source, wind_speed_knots=18, wave_height_m=2.0, visibility_km=8,
    )
    ocean = OceanConditions(
        location=GeoPoint(latitude=13.0, longitude=80.0), observed_at=NOW, source=ocean_source,
        sea_surface_temperature_c=28.0, chlorophyll_mg_m3=0.5, wave_height_m=2.0, sea_state="rough",
    )
    return OrchestratorResult(
        status=DataStatus.SUCCESS,
        parsed_query=ParsedQuery(
            raw_text="safe at 13.0, 80.0", location=GeoPoint(latitude=13.0, longitude=80.0),
            time_window=WINDOW, components=QueryComponents(weather=True, ocean=True, risk=True),
        ),
        weather=WeatherAgentResult(status=DataStatus.SUCCESS, findings=[weather]),
        ocean=OceanAgentResult(status=DataStatus.SUCCESS, conditions=ocean),
        risk=risk,
    )


def test_recommendation_exposes_only_returned_risk_values_and_provenance() -> None:
    risk = RiskAssessmentResult(
        overall_score=75, category=RiskCategory.SEVERE, recommendation=Recommendation.DO_NOT_GO,
        policy_version="mvp-1", reproducibility_inputs={},
        factors=[
            RiskFactor(
                id="wind", measured_value=18, threshold=15, contribution_points=55,
                severity=RiskCategory.SEVERE, reason_code="WIND_ABOVE_LIMIT", rationale="Wind speed above vessel comfort limit",
            ),
            RiskFactor(
                id="sea_state", measured_value=None, threshold="calm/smooth", contribution_points=0,
                severity=RiskCategory.LOW, data_available=False, reason_code="SEA_STATE_MISSING", rationale="Sea state not reported",
            ),
        ],
    )

    view = EvidenceRecommendationService().build(_result(risk=risk))

    assert view.recommendation == Recommendation.DO_NOT_GO
    assert view.overall_risk_score == 75
    assert view.key_reasons[0].code == "WIND_ABOVE_LIMIT"
    assert view.key_reasons[0].measured_value == 18
    assert view.missing_critical_data[0].field == "sea_state"
    assert view.missing_critical_data[0].reason == "Sea state not reported"
    assert {(source.provider, source.dataset, source.observed_at) for source in view.sources} == {
        ("weather-provider", "forecast-v1", NOW),
        ("ocean-provider", "ocean-v1", NOW),
    }
    assert {value.value for value in view.relevant_values} >= {18, 28.0, "rough"}
    weather_wind = next(value for value in view.relevant_values if value.field == "wind_speed_knots")
    assert weather_wind.source is not None
    assert weather_wind.source.provider == "weather-provider"


def test_recommendation_never_fabricates_a_decision_when_risk_is_absent() -> None:
    view = EvidenceRecommendationService().build(_result(risk=None))

    assert view.recommendation is None
    assert view.risk_category is None
    assert view.overall_risk_score is None
    assert view.key_reasons == []
    assert len(view.missing_critical_data) == 1
    assert view.missing_critical_data[0].field == "risk_assessment"
    assert view.missing_critical_data[0].reason is None
