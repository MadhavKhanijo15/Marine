"""Geometry calculations isolated from agents and language-model behavior."""

from __future__ import annotations

from math import asin, cos, radians, sin, sqrt

from shapely.geometry import shape

from app.domain import GeoPoint, GeoSearchRequest, GeoSearchResult, ZoneSpatialAssessment

EARTH_RADIUS_KM = 6371.0088
CALCULATION_VERSION = "geo-mvp-1"


def haversine_distance_km(start: GeoPoint, end: GeoPoint) -> float:
    """Great-circle distance between two WGS84 points."""
    latitude_delta = radians(end.latitude - start.latitude)
    longitude_delta = radians(end.longitude - start.longitude)
    latitude_a = radians(start.latitude)
    latitude_b = radians(end.latitude)
    a = sin(latitude_delta / 2) ** 2 + cos(latitude_a) * cos(latitude_b) * sin(longitude_delta / 2) ** 2
    return EARTH_RADIUS_KM * 2 * asin(sqrt(a))


def geometry_centroid(geometry: dict) -> GeoPoint:
    """Return the deterministic Shapely centroid of a GeoJSON geometry."""
    center = shape(geometry).centroid
    return GeoPoint(latitude=center.y, longitude=center.x)


class GeospatialService:
    """Filters zones with declared, reproducible spatial rules."""

    def assess(self, request: GeoSearchRequest) -> GeoSearchResult:
        hazards = [shape(feature["geometry"] if "geometry" in feature else feature) for feature in request.hazard_features]
        permitted = shape(request.permitted_area) if request.permitted_area else None
        assessments: list[ZoneSpatialAssessment] = []
        for zone in request.candidate_zones:
            zone_shape = shape(zone.geometry)
            center = zone_shape.centroid
            centroid = geometry_centroid(zone.geometry)
            distance = haversine_distance_km(request.origin, centroid)
            intersects_hazard = any(zone_shape.intersects(hazard) for hazard in hazards)
            inside_permitted = permitted is None or permitted.contains(zone_shape)
            reasons: list[str] = []
            if intersects_hazard:
                reasons.append("intersects_hazard")
            if not inside_permitted:
                reasons.append("outside_permitted_area")
            if request.max_distance_km is not None and distance > request.max_distance_km:
                reasons.append("beyond_max_distance")
            assessments.append(
                ZoneSpatialAssessment(
                    zone_id=zone.zone_id,
                    centroid=centroid,
                    distance_from_origin_km=round(distance, 3),
                    intersects_hazard=intersects_hazard,
                    inside_permitted_area=inside_permitted,
                    excluded=bool(reasons),
                    exclusion_reasons=reasons,
                    route_geometry={
                        "type": "LineString", "coordinates": [[request.origin.longitude, request.origin.latitude], [center.x, center.y]]
                    },
                )
            )
        return GeoSearchResult(
            ranked_candidates=sorted(assessments, key=lambda item: (item.excluded, item.distance_from_origin_km)),
            calculation_version=CALCULATION_VERSION,
        )
