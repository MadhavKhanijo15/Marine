"""Geofencing Agent: deterministic containment checks against restricted marine areas.

This agent owns no GeoJSON parsing and no Shapely calculations itself. It only:
  1. asks a ``RestrictedZoneProvider`` for the current set of typed restricted
     zones (GeoJSON loading stays in the data/service layer), and
  2. delegates the actual point-in-polygon / intersection logic to the
     deterministic functions in ``app.geospatial.service``.

No routing, navigation, or route optimization lives here -- this only answers
"is this point/PFZ inside a restricted or protected area, and why".
"""

from __future__ import annotations

from app.domain import (
    DataStatus,
    GeofenceAgentResult,
    GeofenceBatchQuery,
    GeofenceCheckResult,
    GeofenceQuery,
    GeofenceViolation,
    PFZGeofenceAssessment,
    RestrictedZone,
)
from app.geospatial.service import (
    InvalidGeometryError,
    build_restriction_message,
    find_zones_containing_point,
    find_zones_intersecting_geometry,
)
from app.services.interfaces import RestrictedZoneProvider


def _to_violation(zone: RestrictedZone) -> GeofenceViolation:
    return GeofenceViolation(
        zone_id=zone.zone_id,
        zone_name=zone.name,
        restriction_type=zone.restriction_type,
        message=build_restriction_message(zone),
        authority=zone.authority,
    )


class GeofencingAgent:
    """Checks user locations and/or PFZ geometries against restricted zones."""

    def __init__(self, provider: RestrictedZoneProvider) -> None:
        self._provider = provider

    def check_location(self, task: GeofenceQuery) -> GeofenceCheckResult:
        """Check a single point (e.g. a user's current location) in isolation."""
        zones = self._provider.get_restricted_zones()
        warnings: list[str] = []
        try:
            matches = find_zones_containing_point(task.location, zones)
        except InvalidGeometryError as exc:
            return GeofenceCheckResult(
                status=DataStatus.UNAVAILABLE,
                location=task.location,
                inside_restricted_zone=False,
                violations=[],
                warnings=[str(exc)],
            )
        return GeofenceCheckResult(
            status=DataStatus.SUCCESS,
            location=task.location,
            inside_restricted_zone=bool(matches),
            violations=[_to_violation(zone) for zone in matches],
            warnings=warnings,
        )

    def execute(self, task: GeofenceBatchQuery) -> GeofenceAgentResult:
        """Check an optional location and/or a batch of named PFZ geometries."""
        zones = self._provider.get_restricted_zones()
        warnings: list[str] = []

        location_assessment: GeofenceCheckResult | None = None
        if task.location is not None:
            location_assessment = self.check_location(GeofenceQuery(location=task.location))
            warnings.extend(location_assessment.warnings)

        pfz_assessments: list[PFZGeofenceAssessment] = []
        for pfz in task.pfzs:
            try:
                matches = find_zones_intersecting_geometry(pfz.geometry, zones)
            except InvalidGeometryError as exc:
                warnings.append(f"PFZ '{pfz.pfz_id}': {exc}")
                pfz_assessments.append(
                    PFZGeofenceAssessment(pfz_id=pfz.pfz_id, inside_restricted_zone=False, violations=[])
                )
                continue
            pfz_assessments.append(
                PFZGeofenceAssessment(
                    pfz_id=pfz.pfz_id,
                    inside_restricted_zone=bool(matches),
                    violations=[_to_violation(zone) for zone in matches],
                )
            )

        if location_assessment is None and not pfz_assessments:
            status = DataStatus.UNAVAILABLE
        elif warnings:
            status = DataStatus.PARTIAL
        else:
            status = DataStatus.SUCCESS

        return GeofenceAgentResult(
            status=status,
            location_assessment=location_assessment,
            pfz_assessments=pfz_assessments,
            warnings=warnings,
        )
