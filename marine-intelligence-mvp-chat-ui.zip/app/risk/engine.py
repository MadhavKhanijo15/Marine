"""Versioned, deterministic marine risk scoring.

The scoring policy used here (thresholds, point weights, and score bands) is
a set of demo heuristics for the MVP. It is derived from no official
maritime safety standard and must never be presented to a user as one -- see
``app.risk.policy.RiskPolicy`` for every configurable number and
``RiskAssessmentResult.disclaimer`` for the disclaimer attached to every
result.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from app.domain import (
    Recommendation,
    RiskAssessmentInput,
    RiskAssessmentResult,
    RiskCategory,
    RiskFactor,
)
from app.risk.policy import DEFAULT_RISK_POLICY, RiskPolicy


class RiskEngine(ABC):
    @abstractmethod
    def assess(self, assessment: RiskAssessmentInput) -> RiskAssessmentResult:
        """Calculate a reproducible risk result from normalized facts."""


class DeterministicRiskEngine(RiskEngine):
    """Small, explicit, versioned policy suitable for the MVP.

    Every threshold and point weight lives in ``RiskPolicy`` (see
    ``app/risk/policy.py``) so the scoring stays inspectable and swappable
    without touching this class. Missing inputs are never silently treated
    as safe: a factor with no data contributes zero points but is flagged
    with ``data_available=False`` and a ``*_DATA_UNAVAILABLE`` reason code,
    so callers can tell "checked and fine" apart from "not checked".
    """

    def __init__(self, policy: RiskPolicy = DEFAULT_RISK_POLICY) -> None:
        self._policy = policy

    def _factor_severity(self, points: int) -> RiskCategory:
        policy = self._policy
        if points == 0:
            return RiskCategory.LOW
        if points <= policy.factor_moderate_max:
            return RiskCategory.MODERATE
        if points <= policy.factor_high_max:
            return RiskCategory.HIGH
        return RiskCategory.SEVERE

    def _missing(self, factor_id: str, threshold: float | str, rationale: str) -> RiskFactor:
        return RiskFactor(
            id=factor_id,
            measured_value=None,
            threshold=threshold,
            contribution_points=0,
            severity=RiskCategory.LOW,
            data_available=False,
            reason_code=f"{factor_id.upper()}_DATA_UNAVAILABLE",
            rationale=rationale,
        )

    def _numeric_factor(
        self,
        factor_id: str,
        value: float | None,
        threshold: float,
        points: int,
        exceeds_reason: str,
        exceeds_code: str,
        within_reason: str,
        missing_reason: str,
    ) -> RiskFactor:
        if value is None:
            return self._missing(factor_id, threshold, missing_reason)
        exceeds = value > threshold
        contribution = points if exceeds else 0
        return RiskFactor(
            id=factor_id,
            measured_value=value,
            threshold=threshold,
            contribution_points=contribution,
            severity=self._factor_severity(contribution),
            data_available=True,
            reason_code=exceeds_code if exceeds else f"{factor_id.upper()}_WITHIN_LIMIT",
            rationale=exceeds_reason if exceeds else within_reason,
        )

    def assess(self, assessment: RiskAssessmentInput) -> RiskAssessmentResult:
        policy = self._policy
        weather = assessment.weather
        ocean = assessment.ocean
        profile = assessment.vessel_profile
        factors: list[RiskFactor] = []

        factors.append(
            self._numeric_factor(
                "wind",
                weather.wind_speed_knots,
                profile.max_comfortable_wind_knots,
                policy.wind_exceeds_points,
                exceeds_reason="Wind speed above vessel comfort limit",
                exceeds_code="WIND_ABOVE_LIMIT",
                within_reason="Wind speed within vessel comfort limit",
                missing_reason="Wind speed not reported; treated as zero contribution, not as safe",
            )
        )
        factors.append(
            self._numeric_factor(
                "waves",
                weather.wave_height_m,
                profile.max_comfortable_wave_height_m,
                policy.wave_exceeds_points,
                exceeds_reason="Wave height above vessel comfort limit",
                exceeds_code="WAVES_ABOVE_LIMIT",
                within_reason="Wave height within vessel comfort limit",
                missing_reason="Wave height not reported; treated as zero contribution, not as safe",
            )
        )

        if weather.visibility_km is None:
            factors.append(
                self._missing(
                    "visibility",
                    policy.visibility_floor_km,
                    "Visibility not reported; treated as zero contribution, not as safe",
                )
            )
        else:
            low_visibility = weather.visibility_km < policy.visibility_floor_km
            contribution = policy.visibility_points if low_visibility else 0
            factors.append(
                RiskFactor(
                    id="visibility",
                    measured_value=weather.visibility_km,
                    threshold=policy.visibility_floor_km,
                    contribution_points=contribution,
                    severity=self._factor_severity(contribution),
                    data_available=True,
                    reason_code="LOW_VISIBILITY" if low_visibility else "VISIBILITY_WITHIN_LIMIT",
                    rationale=(
                        f"Visibility below {policy.visibility_floor_km:g} km"
                        if low_visibility
                        else f"Visibility at or above {policy.visibility_floor_km:g} km"
                    ),
                )
            )

        factors.append(
            self._numeric_factor(
                "thunderstorm",
                weather.thunderstorm_probability,
                policy.thunderstorm_probability_threshold,
                policy.thunderstorm_points,
                exceeds_reason="Elevated thunderstorm/lightning probability",
                exceeds_code="LIGHTNING_RISK_ELEVATED",
                within_reason="Thunderstorm/lightning probability within acceptable range",
                missing_reason="Thunderstorm probability not reported; treated as zero contribution, not as safe",
            )
        )

        active_storm_alerts = [
            alert
            for alert in weather.alerts
            if any(keyword in alert.lower() for keyword in policy.storm_warning_keywords)
        ]
        storm_active = bool(active_storm_alerts)
        storm_points = policy.storm_warning_points if storm_active else 0
        factors.append(
            RiskFactor(
                id="storm_warning",
                measured_value=storm_active,
                threshold="no active cyclone/storm warning",
                contribution_points=storm_points,
                severity=self._factor_severity(storm_points),
                data_available=True,
                reason_code="STORM_WARNING_ACTIVE" if storm_active else "NO_STORM_WARNING",
                rationale=(
                    f"Active storm/cyclone warning: {'; '.join(active_storm_alerts)}"
                    if storm_active
                    else "No cyclone/storm warning present in reported alerts"
                ),
            )
        )

        if ocean is None or ocean.sea_state is None:
            factors.append(
                self._missing(
                    "sea_state",
                    "calm/smooth",
                    "Sea state not reported; treated as zero contribution, not as safe",
                )
            )
        else:
            normalized_state = ocean.sea_state.strip().lower()
            if normalized_state in policy.sea_state_points:
                contribution = policy.sea_state_points[normalized_state]
                factors.append(
                    RiskFactor(
                        id="sea_state",
                        measured_value=ocean.sea_state,
                        threshold="calm/smooth",
                        contribution_points=contribution,
                        severity=self._factor_severity(contribution),
                        data_available=True,
                        reason_code="ROUGH_SEA_STATE" if contribution > 0 else "SEA_STATE_WITHIN_LIMIT",
                        rationale=f"Reported sea state: {ocean.sea_state}",
                    )
                )
            else:
                factors.append(
                    RiskFactor(
                        id="sea_state",
                        measured_value=ocean.sea_state,
                        threshold="calm/smooth",
                        contribution_points=0,
                        severity=RiskCategory.LOW,
                        data_available=False,
                        reason_code="SEA_STATE_UNRECOGNIZED",
                        rationale=f"Sea state '{ocean.sea_state}' is not a recognized policy value",
                    )
                )

        if assessment.spatial_assessment is None:
            factors.append(
                self._missing(
                    "hazard_intersection",
                    "no hazard intersection",
                    "Spatial hazard assessment not provided; treated as zero contribution, not as safe",
                )
            )
        else:
            hazard = assessment.spatial_assessment.intersects_hazard
            hazard_points = policy.hazard_intersection_points if hazard else 0
            factors.append(
                RiskFactor(
                    id="hazard_intersection",
                    measured_value=hazard,
                    threshold="no hazard intersection",
                    contribution_points=hazard_points,
                    severity=self._factor_severity(hazard_points),
                    data_available=True,
                    reason_code="HAZARD_ZONE_INTERSECTION" if hazard else "NO_HAZARD_INTERSECTION",
                    rationale=(
                        "Selected zone intersects a known hazard"
                        if hazard
                        else "Selected zone does not intersect a known hazard"
                    ),
                )
            )

        score = min(100, sum(factor.contribution_points for factor in factors))
        if score <= policy.overall_low_max:
            category, recommendation = RiskCategory.LOW, Recommendation.GO
        elif score <= policy.overall_moderate_max:
            category, recommendation = RiskCategory.MODERATE, Recommendation.PROCEED_WITH_CAUTION
        elif score <= policy.overall_high_max:
            category, recommendation = RiskCategory.HIGH, Recommendation.POSTPONE
        else:
            category, recommendation = RiskCategory.SEVERE, Recommendation.DO_NOT_GO

        reason_codes = [factor.reason_code for factor in factors if factor.contribution_points > 0]
        reason_codes.extend(factor.reason_code for factor in factors if not factor.data_available)

        return RiskAssessmentResult(
            overall_score=score,
            category=category,
            recommendation=recommendation,
            factors=factors,
            reason_codes=reason_codes,
            policy_version=assessment.policy_version,
            disclaimer=policy.disclaimer,
            reproducibility_inputs=assessment.model_dump(mode="json"),
        )
