from datetime import datetime, timedelta, timezone

import pytest
from pydantic import ValidationError

from app.agents.ocean import OceanIntelligenceAgent
from app.domain import (
    GeoPoint,
    OceanConditions,
    OceanQuery,
    OceanSourceMetadata,
    TimeWindow,
)
from app.services.mock.providers import DemoOceanDataProvider


def query() -> OceanQuery:
    start = datetime(2026, 9, 12, 6, tzinfo=timezone.utc)
    return OceanQuery(
        location=GeoPoint(latitude=13.0, longitude=80.0),
        time_window=TimeWindow(start=start, end=start + timedelta(hours=3)),
    )


def test_ocean_agent_returns_valid_demo_conditions_with_provenance() -> None:
    task = query()
    result = OceanIntelligenceAgent(DemoOceanDataProvider()).execute(task)

    assert result.status == "success"
    assert result.conditions.location == task.location
    assert result.conditions.sea_surface_temperature_c == 28.4
    assert result.conditions.chlorophyll_mg_m3 == 0.73
    assert result.conditions.wave_height_m == 1.1
    assert result.conditions.source.provider == "demo-ocean-data-service"
    assert result.conditions.observed_at.isoformat() == "2026-09-12T00:00:00+00:00"


def test_ocean_conditions_accept_missing_optional_wave_fields() -> None:
    observation = OceanConditions(
        location=GeoPoint(latitude=13.0, longitude=80.0),
        observed_at=datetime(2026, 9, 12, tzinfo=timezone.utc),
        source=OceanSourceMetadata(
            provider="test-provider", dataset="test-dataset", retrieved_at=datetime(2026, 9, 12, tzinfo=timezone.utc)
        ),
        sea_surface_temperature_c=28.0,
        chlorophyll_mg_m3=0.5,
        wave_height_m=0.7,
    )

    assert observation.wave_period_s is None
    assert observation.sea_state is None


def test_ocean_conditions_reject_invalid_wave_height() -> None:
    with pytest.raises(ValidationError, match="wave_height_m"):
        OceanConditions(
            location=GeoPoint(latitude=13.0, longitude=80.0),
            observed_at=datetime(2026, 9, 12, tzinfo=timezone.utc),
            source=OceanSourceMetadata(
                provider="test-provider", dataset="test-dataset", retrieved_at=datetime(2026, 9, 12, tzinfo=timezone.utc)
            ),
            sea_surface_temperature_c=28.0,
            chlorophyll_mg_m3=0.5,
            wave_height_m=-0.1,
        )
