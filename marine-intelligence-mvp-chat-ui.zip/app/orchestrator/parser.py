"""Deterministic, rule-based interpretation of natural-language marine queries.

This is intentionally not an LLM: intent, location, radius, and time are all
extracted with plain keyword and regex matching, so the same input text
always parses to the same ``ParsedQuery`` -- there is nothing to invent and
nothing that varies between runs. This is an MVP heuristic parser, not a
general NLU system, and it does not track anything across calls.
"""

from __future__ import annotations

import re
from datetime import datetime, timedelta, timezone

from pydantic import ValidationError

from app.domain import GeoPoint, ParsedQuery, QueryComponents, TimeWindow

DEFAULT_WINDOW_HOURS = 6

_WEATHER_KEYWORDS = (
    "weather",
    "wind",
    "rain",
    "storm",
    "visibility",
    "forecast",
    "thunderstorm",
    "lightning",
)
_OCEAN_KEYWORDS = ("ocean", "sea surface", "temperature", "chlorophyll", "sst", "sea condition")
_PFZ_KEYWORDS = ("fish", "fishing", "pfz", "catch", "potential fishing zone")
_RISK_KEYWORDS = ("risk", "safe", "safety", "danger", "advisory", "go out", "should i go")
_GEOFENCE_KEYWORDS = (
    "restricted",
    "protected area",
    "marine protected area",
    "mpa",
    "no-fishing zone",
    "no fishing zone",
    "exclusion zone",
    "geofence",
    "off-limits",
    "off limits",
    "allowed to fish",
    "am i allowed",
)

_LAT_LON_LABELED = re.compile(
    r"lat(?:itude)?[:\s]*(-?\d+(?:\.\d+)?)[,;\s]+lon(?:g|gitude)?[:\s]*(-?\d+(?:\.\d+)?)",
    re.IGNORECASE,
)
_LAT_LON_DIRECTIONAL = re.compile(r"(\d+(?:\.\d+)?)\s*°?\s*([NSns])[,\s]+(\d+(?:\.\d+)?)\s*°?\s*([EWew])")
_LAT_LON_PAIR = re.compile(r"(-?\d{1,3}(?:\.\d+)?)\s*,\s*(-?\d{1,3}(?:\.\d+)?)")
_RADIUS = re.compile(r"(?:within\s+)?(\d+(?:\.\d+)?)\s*(?:km|kilometers?|kilometres?)\b", re.IGNORECASE)
_NEXT_N_HOURS = re.compile(r"next\s+(\d+)\s*hours?", re.IGNORECASE)
_NEXT_N_DAYS = re.compile(r"next\s+(\d+)\s*days?", re.IGNORECASE)
_TOMORROW = re.compile(r"\btomorrow\b", re.IGNORECASE)
_SELECTED_PFZ = re.compile(r"\b(?:selected\s+)?(pfz[-_][a-z0-9_-]+)\b", re.IGNORECASE)
_SAFER_ZONE_KEYWORDS = ("safer zone", "safer-zone", "alternative zone")


def _safe_point(latitude: float, longitude: float, warnings: list[str]) -> GeoPoint | None:
    try:
        return GeoPoint(latitude=latitude, longitude=longitude)
    except ValidationError:
        warnings.append(
            "Found coordinate-like numbers but they are outside valid lat/lon range; location ignored."
        )
        return None


def _extract_location(text: str, warnings: list[str]) -> GeoPoint | None:
    match = _LAT_LON_LABELED.search(text)
    if match:
        return _safe_point(float(match.group(1)), float(match.group(2)), warnings)

    match = _LAT_LON_DIRECTIONAL.search(text)
    if match:
        latitude = float(match.group(1)) * (-1 if match.group(2).lower() == "s" else 1)
        longitude = float(match.group(3)) * (-1 if match.group(4).lower() == "w" else 1)
        return _safe_point(latitude, longitude, warnings)

    match = _LAT_LON_PAIR.search(text)
    if match:
        return _safe_point(float(match.group(1)), float(match.group(2)), warnings)

    return None


def _extract_radius_km(text: str) -> float | None:
    match = _RADIUS.search(text)
    return float(match.group(1)) if match else None


def _extract_time_window(text: str, now: datetime) -> tuple[TimeWindow, bool]:
    if _TOMORROW.search(text):
        start = now + timedelta(days=1)
        return TimeWindow(start=start, end=start + timedelta(hours=DEFAULT_WINDOW_HOURS)), True

    match = _NEXT_N_DAYS.search(text)
    if match:
        return TimeWindow(start=now, end=now + timedelta(days=int(match.group(1)))), True

    match = _NEXT_N_HOURS.search(text)
    if match:
        return TimeWindow(start=now, end=now + timedelta(hours=int(match.group(1)))), True

    return TimeWindow(start=now, end=now + timedelta(hours=DEFAULT_WINDOW_HOURS)), False


def _extract_components(text: str, radius_km: float | None) -> QueryComponents:
    lowered = text.lower()
    weather = any(keyword in lowered for keyword in _WEATHER_KEYWORDS)
    ocean = any(keyword in lowered for keyword in _OCEAN_KEYWORDS)
    pfz = any(keyword in lowered for keyword in _PFZ_KEYWORDS)
    risk = any(keyword in lowered for keyword in _RISK_KEYWORDS)
    geofence = any(keyword in lowered for keyword in _GEOFENCE_KEYWORDS)
    safer_zone = any(keyword in lowered for keyword in _SAFER_ZONE_KEYWORDS)
    if safer_zone:
        pfz = True
        risk = True

    if not any((weather, ocean, pfz, risk, geofence)):
        # No recognizable keyword at all: fall back to a general briefing
        # rather than guessing at a single intent.
        weather = ocean = pfz = risk = geofence = True

    # A PFZ request that also names a radius is a geospatial (radius-filtered)
    # request rather than a plain "list nearby zones" request.
    geospatial = pfz and (radius_km is not None or safer_zone)

    return QueryComponents(weather=weather, ocean=ocean, pfz=pfz, geospatial=geospatial, risk=risk, geofence=geofence)


def parse_query(text: str, *, now: datetime | None = None) -> ParsedQuery:
    """Deterministically extract intent, location, radius, and a time window from free text."""

    reference_time = now or datetime.now(timezone.utc)
    warnings: list[str] = []

    location = _extract_location(text, warnings)
    radius_km = _extract_radius_km(text)
    components = _extract_components(text, radius_km)
    time_window, time_window_explicit = _extract_time_window(text, reference_time)
    selected_match = _SELECTED_PFZ.search(text)

    if location is None:
        warnings.append("No latitude/longitude found in the query; location-based components were skipped.")

    return ParsedQuery(
        raw_text=text,
        location=location,
        radius_km=radius_km,
        time_window=time_window,
        time_window_explicit=time_window_explicit,
        selected_pfz_id=selected_match.group(1) if selected_match else None,
        components=components,
        warnings=warnings,
    )
