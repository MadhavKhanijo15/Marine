# Marine Intelligence Assistant backend

Minimal, deterministic backend foundation for the Marine Intelligence Assistant MVP.

## Run locally

From this `backend` directory:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Check the service at `http://127.0.0.1:8000/health` and API documentation at
`http://127.0.0.1:8000/docs`.

Open `http://127.0.0.1:8000/` for the marine map MVP. It requests the
browser's location only after the user selects **Use my location**, then calls
`/api/marine-briefing`. That endpoint invokes the existing orchestrator and
returns its weather, ocean, PFZ, risk, geofence (when relevant), and
evidence-recommendation results. The Leaflet client only renders those
returned fields -- including surfacing any geofence-violation warning in the
status line -- and performs no marine calculation, routing, geofencing, or
memory of its own.

## Follow-up conversations

`POST /api/conversations/turn` accepts a `conversation_id`, text, and optional
selected PFZ/area. It keeps only the explicit location, time window, selected
PFZ ID, and selected area for that in-process conversation. A follow-up such
as "Find a safer zone tomorrow" reuses a known location and selection while
changing only the stated time. If a location was never supplied, it remains
missing and the existing orchestrator reports unavailable location-dependent
data. Context is process-local and is not durable storage.

## Test

```powershell
pytest
```

The application deliberately exposes only health at this stage. Chat, LLM
integration, and frontend work are intentionally out of scope.

## Geofencing (restricted/protected marine areas)

`app/agents/geofencing.py` provides a `GeofencingAgent` that checks a single
location and/or a batch of named PFZ geometries against seeded
restricted/protected marine area polygons (marine protected areas,
no-fishing zones, naval exclusion zones). It returns whether each check is
inside a restricted zone and a clear, human-readable warning message per
matched zone (name, restriction type, and any description/authority).

All GeoJSON loading and parsing stays in the data/service layer:
- `app/data/restricted_zones_demo.geojson` holds the seeded polygons.
- `app/services/mock/providers.py::DemoRestrictedZoneProvider` loads them into
  typed `RestrictedZone` records.
- `app/geospatial/service.py` holds the deterministic Shapely logic
  (`find_zones_containing_point`, `find_zones_intersecting_geometry`,
  `build_restriction_message`) and raises `InvalidGeometryError` for any
  polygon (seeded or supplied) that cannot be parsed, rather than silently
  treating an unparseable zone as "not restricted".

The agent itself never reads GeoJSON or calls Shapely directly -- it only
resolves a `RestrictedZoneProvider` and calls the service functions above.

**Wired into the orchestrator.** `MainOrchestratorAgent` takes an optional
`geofence_agent`; `build_demo_orchestrator()` supplies one backed by the
seeded demo zones. A query containing a restricted-area keyword ("restricted",
"protected area", "mpa", "exclusion zone", "off-limits", ...) sets
`components.geofence`, and the check result is returned on
`OrchestratorResult.geofence`. When a violation is found, its warning message
is appended to `OrchestratorResult.warnings` -- the *existing*,
unmodified `EvidenceRecommendationService` already forwards `warnings`
verbatim, so no recommendation-layer change was needed for the frontend's
status line to display it. If no `geofence_agent` is configured, the check
is silently skipped (not a warning) -- that mirrors how `RouteOptimizationAgent`
treats its own optional risk inputs: absence of configuration is a caller
choice, not missing data. Route optimization (`app/routing/`,
`app/agents/routing.py`) still exists only as a standalone, directly-testable
component and is not wired into the orchestrator or API.

## Error handling / graceful degradation

Every provider-backed agent call inside `MainOrchestratorAgent.execute()`
(weather, ocean, PFZ, geospatial, geofencing) is wrapped in a single error
boundary (`_safe_call` in `app/orchestrator/agent.py`): if a provider raises,
that component's result becomes `None` and a `"<Component> unavailable: ..."`
warning is appended -- the whole briefing never crashes, and a failed
component is never silently treated as "fine"/"safe". This also means the
risk engine's existing "missing input -> unavailable, not safe" behavior
(see `app/risk/engine.py`) is reachable even when the failure originates at
the provider/network layer, not just when a component was never requested.

## Evidence and recommendation output

`MainOrchestratorAgent.execute()` now includes an `evidence_recommendation`
field in its `OrchestratorResult`. It is a frontend-ready, stateless view of
the already-returned agent data: the risk engine's recommendation and reasons,
observed values, provider/evidence provenance and timestamps, and explicitly
reported missing critical data. The layer never creates an operational decision
when the risk engine did not return one, and it does not add maps, routing,
geofencing, or memory.
