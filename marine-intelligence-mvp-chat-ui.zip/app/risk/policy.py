"""Configurable thresholds for the deterministic risk engine.

These numbers are illustrative demo heuristics only. They are not sourced from
any official maritime safety standard (e.g. IMO, national coast guard, or
port authority guidance) and must not be presented to end users as such.
Callers who need a different policy can construct their own ``RiskPolicy``
and pass it to ``DeterministicRiskEngine`` instead of editing these defaults.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

DEMO_DISCLAIMER = "Demo heuristic thresholds only; not an official maritime safety standard."


class RiskPolicy(BaseModel):
    """All magic numbers the risk engine uses, in one inspectable, versioned place."""

    version: str = "mvp-1"

    # Wind / waves are evaluated against the vessel profile's own comfort limits,
    # so only the point contribution is configured here.
    wind_exceeds_points: int = Field(default=25, ge=0)
    wave_exceeds_points: int = Field(default=30, ge=0)

    visibility_floor_km: float = Field(default=5.0, ge=0)
    visibility_points: int = Field(default=15, ge=0)

    thunderstorm_probability_threshold: float = Field(default=0.4, ge=0, le=1)
    thunderstorm_points: int = Field(default=20, ge=0)

    # Any weather alert whose text matches one of these keywords (case-insensitive)
    # is treated as an active cyclone/storm warning.
    storm_warning_keywords: tuple[str, ...] = (
        "cyclone",
        "storm",
        "hurricane",
        "typhoon",
        "gale",
        "warning",
    )
    storm_warning_points: int = Field(default=35, ge=0)

    # Sea-state descriptions (WMO-style, lowercased) mapped to point contributions.
    # Unrecognized strings are treated as missing/unavailable data, not zero risk.
    sea_state_points: dict[str, int] = Field(
        default_factory=lambda: {
            "calm": 0,
            "smooth": 0,
            "slight": 5,
            "moderate": 10,
            "rough": 20,
            "very rough": 30,
            "high": 35,
            "very high": 40,
            "phenomenal": 50,
        }
    )

    hazard_intersection_points: int = Field(default=30, ge=0)

    # Per-factor severity bands, used only to label an individual factor's
    # contribution, not the overall score.
    factor_moderate_max: int = Field(default=10, ge=0)
    factor_high_max: int = Field(default=20, ge=0)

    # Overall-score bands that decide category + recommendation.
    overall_low_max: int = Field(default=15, ge=0)
    overall_moderate_max: int = Field(default=35, ge=0)
    overall_high_max: int = Field(default=60, ge=0)

    disclaimer: str = DEMO_DISCLAIMER


DEFAULT_RISK_POLICY = RiskPolicy()
