/* The map is intentionally a visualizer: it renders fields returned by the API
 * and sends the browser location to the backend. It calculates no PFZ/risk data. */
// A neutral viewport until the browser provides a location; no marine result is
// embedded in the client.
const map = L.map("map", { zoomControl: true }).setView([0, 0], 2);
L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  maxZoom: 18,
  attribution: "&copy; OpenStreetMap contributors",
}).addTo(map);

let renderedLayers = [];
const conversationStorageKey = "marine-intelligence-conversation-id";
const conversationId = sessionStorage.getItem(conversationStorageKey) || crypto.randomUUID();
sessionStorage.setItem(conversationStorageKey, conversationId);
let selectedPfzId = null;
const status = document.querySelector("#status");
const labels = {
  wind_speed_knots: "Wind", wave_height_m: "Wave height", rainfall_mm: "Rainfall",
  visibility_km: "Visibility", thunderstorm_probability: "Thunderstorm probability",
  sea_surface_temperature_c: "Sea-surface temperature", chlorophyll_mg_m3: "Chlorophyll",
  wave_period_s: "Wave period", sea_state: "Sea state",
};
const units = {
  wind_speed_knots: " kn", wave_height_m: " m", rainfall_mm: " mm", visibility_km: " km",
  sea_surface_temperature_c: " °C", chlorophyll_mg_m3: " mg/m³", wave_period_s: " s",
};

function clearLayers() {
  renderedLayers.forEach((layer) => map.removeLayer(layer));
  renderedLayers = [];
}

function text(value) { return value === null || value === undefined ? "Not reported" : String(value); }
function escapeHtml(value) {
  return text(value).replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character]);
}
function format(field, value) {
  if (field === "thunderstorm_probability" && value !== null && value !== undefined) return `${Math.round(value * 100)}%`;
  return `${text(value)}${units[field] || ""}`;
}
function showValues(elementId, data, fields) {
  document.querySelector(elementId).innerHTML = fields
    .filter((field) => data && data[field] !== null && data[field] !== undefined)
    .map((field) => `<dt>${escapeHtml(labels[field])}</dt><dd>${escapeHtml(format(field, data[field]))}</dd>`)
    .join("") || "<dt>Data</dt><dd>Not returned</dd>";
}

function renderBriefing(result) {
  const weather = result.weather?.findings?.[0];
  const ocean = result.ocean?.conditions;
  const recommendation = result.evidence_recommendation;
  const risk = result.risk;
  const riskElement = document.querySelector("#risk");
  const riskLevel = recommendation?.risk_category || risk?.category;
  riskElement.className = riskLevel ? `risk-${riskLevel}` : "";
  riskElement.textContent = recommendation?.recommendation
    ? `${recommendation.recommendation.replaceAll("_", " ")} · ${recommendation.overall_risk_score}/100 (${riskLevel})`
    : "Risk assessment was not returned.";
  showValues("#weather", weather, ["wind_speed_knots", "wave_height_m", "rainfall_mm", "visibility_km", "thunderstorm_probability"]);
  showValues("#ocean", ocean, ["sea_surface_temperature_c", "chlorophyll_mg_m3", "wave_height_m", "wave_period_s", "sea_state"]);

  const pfzs = result.geospatial?.nearby_pfzs || result.pfz?.nearby_pfzs || [];
  document.querySelector("#pfzs").innerHTML = pfzs.map((pfz) =>
    `<li>${escapeHtml(pfz.pfz_id)} — ${escapeHtml(pfz.distance_km)} km</li>`
  ).join("") || "<li>No PFZs returned.</li>";
  pfzs.forEach((pfz) => {
    const marker = L.marker([pfz.coordinates.latitude, pfz.coordinates.longitude])
      .bindPopup(`<strong>${escapeHtml(pfz.pfz_id)}</strong><br>${escapeHtml(pfz.distance_km)} km (backend-calculated)`)
      .addTo(map);
    marker.on("click", () => { selectedPfzId = pfz.pfz_id; });
    renderedLayers.push(marker);
  });
}

function renderReturnedLocation(result) {
  const location = result.parsed_query?.location;
  if (!location) return;
  const userMarker = L.circleMarker([location.latitude, location.longitude], { radius: 8, color: "#ffffff", fillColor: "#1677ff", fillOpacity: 1 })
    .bindPopup("Your location").addTo(map);
  renderedLayers.push(userMarker);
  map.setView([location.latitude, location.longitude], 9);
}

async function submitConversationTurn(text) {
  clearLayers();
  status.textContent = "Loading backend briefing…";
  try {
    const body = { conversation_id: conversationId, text };
    if (selectedPfzId) body.selected_pfz_id = selectedPfzId;
    const response = await fetch("/api/conversations/turn", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!response.ok) throw new Error(`Briefing request failed (${response.status})`);
    const turn = await response.json();
    renderReturnedLocation(turn.result);
    renderBriefing(turn.result);
    status.textContent = turn.result.warnings?.join(" ") || "Briefing loaded from backend agent data.";
  } catch (error) {
    status.textContent = error.message;
  }
}

document.querySelector("#locate").addEventListener("click", () => {
  if (!navigator.geolocation) { status.textContent = "Browser location is not available."; return; }
  status.textContent = "Requesting browser location…";
  navigator.geolocation.getCurrentPosition(
    ({ coords }) => submitConversationTurn(`marine briefing at ${coords.latitude}, ${coords.longitude}`),
    (error) => { status.textContent = `Location unavailable: ${error.message}`; },
    { enableHighAccuracy: true, timeout: 10000, maximumAge: 0 },
  );
});

document.querySelector("#follow-up").addEventListener("submit", (event) => {
  event.preventDefault();
  const question = document.querySelector("#question");
  const text = question.value.trim();
  if (!text) return;
  submitConversationTurn(text);
  question.value = "";
});
