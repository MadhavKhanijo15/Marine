"""Interfaces future real-world data adapters must preserve."""

from typing import Protocol

from app.domain import (
    FishingZone,
    OceanConditions,
    OceanQuery,
    PFZDataRecord,
    PFZSearchQuery,
    PFZQuery,
    WeatherFinding,
    WeatherQuery,
)


class WeatherProvider(Protocol):
    def get_forecast(self, query: WeatherQuery) -> WeatherFinding: ...


class OceanProvider(Protocol):
    def get_candidate_zones(self, query: PFZQuery) -> list[FishingZone]: ...


class OceanDataProvider(Protocol):
    """Source of normalized physical ocean observations, independent of PFZ data."""

    def get_conditions(self, query: OceanQuery) -> OceanConditions: ...


class PFZDataProvider(Protocol):
    """Source of PFZ observations, separate from physical-ocean and risk services."""

    def get_pfz_records(self, query: PFZSearchQuery) -> list[PFZDataRecord]: ...


class HazardProvider(Protocol):
    def get_hazards(self, query: PFZQuery) -> list[dict]: ...
