from datetime import datetime, timedelta, timezone

from app.agents.weather import WeatherAgent
from app.domain import (
    GeoPoint,
    TimeWindow,
    WeatherFinding,
    WeatherQuery,
    WeatherSourceMetadata,
)


class SpyWeatherProvider:
    """A test double proving the agent uses its provider dependency."""

    def __init__(self, response: WeatherFinding) -> None:
        self.response = response
        self.received_query: WeatherQuery | None = None

    def get_forecast(self, query: WeatherQuery) -> WeatherFinding:
        self.received_query = query
        return self.response


def test_weather_agent_delegates_to_data_service_and_preserves_provenance() -> None:
    start = datetime(2026, 9, 12, 6, tzinfo=timezone.utc)
    query = WeatherQuery(
        location=GeoPoint(latitude=13.0, longitude=80.0),
        time_window=TimeWindow(start=start, end=start + timedelta(hours=3)),
    )
    finding = WeatherFinding(
        location=query.location,
        time_window=query.time_window,
        observed_at=start,
        source=WeatherSourceMetadata(
            provider="test-weather-provider",
            dataset="marine-hourly",
            retrieved_at=start + timedelta(minutes=1),
        ),
        wind_speed_knots=11,
        wave_height_m=0.8,
        visibility_km=9,
    )
    provider = SpyWeatherProvider(finding)

    result = WeatherAgent(provider).execute(query)

    assert provider.received_query == query
    assert result.status == "success"
    assert result.findings == [finding]
    assert result.findings[0].observed_at == start
    assert result.findings[0].source.provider == "test-weather-provider"
    assert result.findings[0].source.retrieved_at == start + timedelta(minutes=1)
