"""JSON/GeoJSON-backed demo provider implementations."""

