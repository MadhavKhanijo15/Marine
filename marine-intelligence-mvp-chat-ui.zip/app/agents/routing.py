"""Route Optimization Agent: deterministic MVP start->destination routing that
avoids known restricted/geofenced marine areas.

This is intentionally a minimal MVP, not professional maritime navigation --
see ``app.routing.service`` for exactly what the simple detour logic does and
does not account for.

No GeoJSON parsing or Shapely calculation lives here. This agent only:
  1. resolves the requested destination -- an explicit point, or an existing
     PFZ id looked up through the already-existing ``PFZDataProvider`` and
     ``geometry_centroid`` helper (no new PFZ data or geometry-parsing logic
     is added),
  2. asks a ``RestrictedZoneProvider`` for the current restricted zones (the
     same provider ``GeofencingAgent`` already uses), and
  3. delegates the actual path/obstacle geometry to ``app.routing.service``.

No existing agent (weather, ocean, PFZ, geospatial, geofencing, or the main
orchestrator) is modified to add this feature. Weather/ocean/risk inputs are
reused exactly as those already-existing agents return them via their own
``execute``/``assess`` methods -- never recomputed or invented here. When
those optional collaborators are not supplied, ``risk_level``/``risk_score``
are simply left unset (never estimated); a warning is only added if risk was
actually attempted and the underlying data came back unavailable.
"""

from __future__ import annotations

from app.agents.ocean import OceanIntelligenceAgent
from app.agents.weather import WeatherAgent
from app.domain import (
    DataStatus,
    GeoPoint,
    GeofenceViolation,
    OceanQuery,
    PFZSearchQuery,
    RestrictedZone,
    RiskAssessmentInput,
    RiskCategory,
    RouteQuery,
    RouteResult,
    WeatherQuery,
)
from app.geospatial.service import InvalidGeometryError, build_restriction_message, geometry_centroid
from app.risk.engine import RiskEngine
from app.routing.service import ROUTE_CALCULATION_VERSION, plan_route
from app.services.interfaces import PFZDataProvider, RestrictedZoneProvider


def _violation(zone: RestrictedZone) -> GeofenceViolation:
    return GeofenceViolation(
        zone_id=zone.zone_id,
        zone_name=zone.name,
        restriction_type=zone.restriction_type,
        message=build_restriction_message(zone),
        authority=zone.authority,
    )


class RouteOptimizationAgent:
    """Plans a simple, deterministic route and reports risk using only existing data."""

    def __init__(
        self,
        restricted_zone_provider: RestrictedZoneProvider,
        pfz_provider: PFZDataProvider | None = None,
        weather_agent: WeatherAgent | None = None,
        ocean_agent: OceanIntelligenceAgent | None = None,
        risk_engine: RiskEngine | None = None,
    ) -> None:
        self._restricted_zone_provider = restricted_zone_provider
        self._pfz_provider = pfz_provider
        self._weather_agent = weather_agent
        self._ocean_agent = ocean_agent
        self._risk_engine = risk_engine

    def _resolve_destination(self, task: RouteQuery) -> tuple[GeoPoint | None, str | None]:
        if task.destination is not None:
            return task.destination, None
        if self._pfz_provider is None:
            return None, f"No PFZ data available to resolve destination PFZ '{task.destination_pfz_id}'."
        records = self._pfz_provider.get_pfz_records(
            PFZSearchQuery(latitude=task.start.latitude, longitude=task.start.longitude)
        )
        match = next((record for record in records if record.pfz_id == task.destination_pfz_id), None)
        if match is None:
            return None, f"Requested PFZ '{task.destination_pfz_id}' was not found; no destination data available."
        return geometry_centroid(match.geometry), None

    def _assess_risk(
        self, task: RouteQuery, reasons: list[str], warnings: list[str]
    ) -> tuple[RiskCategory | None, int | None]:
        # Risk is purely optional here: if the caller did not wire a weather
        # agent/risk engine, that is a deliberate configuration choice, not
        # missing data, so risk_level/risk_score simply stay None -- no
        # warning, and no invented score.
        if self._weather_agent is None or self._risk_engine is None:
            return None, None

        weather_result = self._weather_agent.execute(WeatherQuery(location=task.start, time_window=task.time_window))
        if not weather_result.findings:
            warnings.append("Risk assessment skipped: weather data unavailable for the route start.")
            return None, None

        ocean_result = (
            self._ocean_agent.execute(OceanQuery(location=task.start, time_window=task.time_window))
            if self._ocean_agent is not None
            else None
        )
        risk_result = self._risk_engine.assess(
            RiskAssessmentInput(
                weather=weather_result.findings[0],
                ocean=ocean_result.conditions if ocean_result else None,
            )
        )
        reasons.extend(factor.rationale for factor in risk_result.factors if factor.contribution_points > 0)
        return risk_result.category, risk_result.overall_score

    def execute(self, task: RouteQuery) -> RouteResult:
        warnings: list[str] = []
        reasons: list[str] = []

        destination, destination_warning = self._resolve_destination(task)
        if destination_warning:
            warnings.append(destination_warning)
        if destination is None:
            return RouteResult(
                status=DataStatus.UNAVAILABLE,
                start=task.start,
                destination=task.start,
                destination_pfz_id=task.destination_pfz_id,
                route=[task.start],
                distance_km=0.0,
                detoured=False,
                clear_of_restricted_zones=True,
                geofence_violations=[],
                risk_level=None,
                risk_score=None,
                reasons=reasons,
                warnings=warnings,
                calculation_version=ROUTE_CALCULATION_VERSION,
            )

        zones = self._restricted_zone_provider.get_restricted_zones()
        try:
            plan = plan_route(task.start, destination, zones)
        except InvalidGeometryError as exc:
            warnings.append(str(exc))
            return RouteResult(
                status=DataStatus.UNAVAILABLE,
                start=task.start,
                destination=destination,
                destination_pfz_id=task.destination_pfz_id,
                route=[task.start, destination],
                distance_km=0.0,
                detoured=False,
                clear_of_restricted_zones=False,
                geofence_violations=[],
                risk_level=None,
                risk_score=None,
                reasons=reasons,
                warnings=warnings,
                calculation_version=ROUTE_CALCULATION_VERSION,
            )

        violations = [_violation(zone) for zone in plan.blocking_zones]
        if plan.detoured:
            zone_names = ", ".join(zone.name for zone in plan.blocking_zones)
            reasons.append(f"Direct route intersects restricted zone(s) ({zone_names}); rerouted around them.")
        elif plan.blocking_zones:
            zone_names = ", ".join(zone.name for zone in plan.blocking_zones)
            warnings.append(
                f"Direct route intersects restricted zone(s) ({zone_names}) and no simple detour was clear; "
                "route is returned unmodified and flagged as not clear of restricted zones."
            )

        risk_level, risk_score = self._assess_risk(task, reasons, warnings)

        if not plan.clear_of_restricted_zones:
            status = DataStatus.PARTIAL
        elif warnings:
            status = DataStatus.PARTIAL
        else:
            status = DataStatus.SUCCESS

        return RouteResult(
            status=status,
            start=task.start,
            destination=destination,
            destination_pfz_id=task.destination_pfz_id,
            route=plan.coordinates,
            distance_km=plan.distance_km,
            detoured=plan.detoured,
            clear_of_restricted_zones=plan.clear_of_restricted_zones,
            geofence_violations=violations,
            risk_level=risk_level,
            risk_score=risk_score,
            reasons=reasons,
            warnings=warnings,
            calculation_version=ROUTE_CALCULATION_VERSION,
        )
