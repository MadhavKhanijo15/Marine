"""Replaceable data-provider contracts and implementations."""

