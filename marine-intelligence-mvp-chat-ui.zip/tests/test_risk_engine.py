from datetime import datetime, timedelta, timezone

from app.domain import (
    GeoPoint,
    OceanConditions,
    OceanSourceMetadata,
    RiskAssessmentInput,
    TimeWindow,
    VesselProfile,
    WeatherFinding,
    WeatherSourceMetadata,
    ZoneSpatialAssessment,
)
from app.risk.engine import DeterministicRiskEngine
from app.risk.policy import RiskPolicy


def weather(**updates: float) -> WeatherFinding:
    now = datetime(2026, 9, 12, tzinfo=timezone.utc)
    values = {
        "location": GeoPoint(latitude=13, longitude=80),
        "time_window": TimeWindow(start=now, end=now + timedelta(hours=3)),
        "observed_at": now,
        "source": WeatherSourceMetadata(
            provider="test-provider", dataset="test-dataset", retrieved_at=now
        ),
        "wind_speed_knots": 10,
        "wave_height_m": 1.0,
        "visibility_km": 8,
        "thunderstorm_probability": 0.1,
    }
    values.update(updates)
    return WeatherFinding(**values)


def ocean(**updates: object) -> OceanConditions:
    now = datetime(2026, 9, 12, tzinfo=timezone.utc)
    values = {
        "location": GeoPoint(latitude=13, longitude=80),
        "observed_at": now,
        "source": OceanSourceMetadata(
            provider="test-provider", dataset="test-dataset", retrieved_at=now
        ),
        "sea_surface_temperature_c": 28.0,
        "chlorophyll_mg_m3": 0.5,
        "wave_height_m": 1.0,
        "sea_state": "moderate",
    }
    values.update(updates)
    return OceanConditions(**values)


def hazard_zone(intersects: bool) -> ZoneSpatialAssessment:
    return ZoneSpatialAssessment(
        zone_id="zone-1",
        centroid=GeoPoint(latitude=13, longitude=80),
        distance_from_origin_km=1.0,
        intersects_hazard=intersects,
        inside_permitted_area=True,
        excluded=intersects,
        exclusion_reasons=["intersects_hazard"] if intersects else [],
    )


def test_low_conditions_produce_go_recommendation() -> None:
    result = DeterministicRiskEngine().assess(RiskAssessmentInput(weather=weather()))
    assert result.overall_score == 0
    assert result.category == "low"
    assert result.recommendation == "go"
    # No hazards exceeded a threshold; only the not-provided ocean/spatial
    # inputs show up, flagged as unavailable rather than silently "safe".
    assert result.reason_codes == ["SEA_STATE_DATA_UNAVAILABLE", "HAZARD_INTERSECTION_DATA_UNAVAILABLE"]
    assert result.disclaimer == RiskPolicy().disclaimer


def test_medium_conditions_produce_proceed_with_caution() -> None:
    # Wind alone (25 pts) falls between the low (<=15) and moderate (<=35) bands.
    result = DeterministicRiskEngine().assess(
        RiskAssessmentInput(weather=weather(wind_speed_knots=18))
    )
    assert result.overall_score == 25
    assert result.category == "moderate"
    assert result.recommendation == "proceed_with_caution"
    assert result.reason_codes == [
        "WIND_ABOVE_LIMIT",
        "SEA_STATE_DATA_UNAVAILABLE",
        "HAZARD_INTERSECTION_DATA_UNAVAILABLE",
    ]


def test_high_wind_and_waves_are_deterministic() -> None:
    engine = DeterministicRiskEngine()
    assessment = RiskAssessmentInput(weather=weather(wind_speed_knots=18, wave_height_m=2.0))
    first = engine.assess(assessment)
    second = engine.assess(assessment)
    assert first.overall_score == 55
    assert first.category == "high"
    assert first.model_dump() == second.model_dump()


def test_severe_conditions_from_storm_warning_and_hazard_zone_produce_do_not_go() -> None:
    result = DeterministicRiskEngine().assess(
        RiskAssessmentInput(
            weather=weather(
                wind_speed_knots=18,
                wave_height_m=2.0,
                alerts=["Cyclone warning issued for coastal waters"],
            ),
            ocean=ocean(sea_state="very rough"),
            spatial_assessment=hazard_zone(intersects=True),
        )
    )
    # wind(25) + waves(30) + storm(35) + sea_state very rough(30) + hazard(30) = 150 -> capped at 100
    assert result.overall_score == 100
    assert result.category == "severe"
    assert result.recommendation == "do_not_go"
    assert "STORM_WARNING_ACTIVE" in result.reason_codes
    assert "ROUGH_SEA_STATE" in result.reason_codes
    assert "HAZARD_ZONE_INTERSECTION" in result.reason_codes


def test_missing_weather_data_is_not_treated_as_safe() -> None:
    incomplete_weather = weather(
        wind_speed_knots=None,
        wave_height_m=None,
        visibility_km=None,
        thunderstorm_probability=None,
    )
    result = DeterministicRiskEngine().assess(RiskAssessmentInput(weather=incomplete_weather))

    # No points are fabricated from missing data...
    assert result.overall_score == 0
    assert result.category == "low"

    # ...but every unmeasured factor is explicitly flagged, not silently passed.
    unavailable_factor_ids = {factor.id for factor in result.factors if not factor.data_available}
    assert unavailable_factor_ids == {"wind", "waves", "visibility", "thunderstorm", "sea_state", "hazard_intersection"}
    assert "WIND_DATA_UNAVAILABLE" in result.reason_codes
    assert "WAVES_DATA_UNAVAILABLE" in result.reason_codes
    assert "VISIBILITY_DATA_UNAVAILABLE" in result.reason_codes
    assert "THUNDERSTORM_DATA_UNAVAILABLE" in result.reason_codes
    assert "SEA_STATE_DATA_UNAVAILABLE" in result.reason_codes
    assert "HAZARD_INTERSECTION_DATA_UNAVAILABLE" in result.reason_codes


def test_unrecognized_sea_state_is_flagged_not_scored() -> None:
    result = DeterministicRiskEngine().assess(
        RiskAssessmentInput(weather=weather(), ocean=ocean(sea_state="apocalyptic"))
    )
    sea_state_factor = next(factor for factor in result.factors if factor.id == "sea_state")
    assert sea_state_factor.contribution_points == 0
    assert sea_state_factor.data_available is False
    assert sea_state_factor.reason_code == "SEA_STATE_UNRECOGNIZED"


def test_alerts_without_storm_keywords_do_not_trigger_storm_warning() -> None:
    result = DeterministicRiskEngine().assess(
        RiskAssessmentInput(weather=weather(alerts=["Minor swell advisory"]))
    )
    storm_factor = next(factor for factor in result.factors if factor.id == "storm_warning")
    assert storm_factor.contribution_points == 0
    assert storm_factor.reason_code == "NO_STORM_WARNING"


def test_thresholds_are_configurable_via_risk_policy() -> None:
    strict_policy = RiskPolicy(wind_exceeds_points=90, overall_low_max=0)
    lenient_result = DeterministicRiskEngine().assess(
        RiskAssessmentInput(weather=weather(wind_speed_knots=18))
    )
    strict_result = DeterministicRiskEngine(policy=strict_policy).assess(
        RiskAssessmentInput(weather=weather(wind_speed_knots=18))
    )
    assert lenient_result.overall_score == 25
    assert strict_result.overall_score == 90
    assert strict_result.category == "severe"
    assert strict_result.disclaimer == strict_policy.disclaimer


def test_vessel_profile_changes_wind_and_wave_thresholds() -> None:
    tolerant_profile = VesselProfile(max_comfortable_wind_knots=30, max_comfortable_wave_height_m=3.0)
    result = DeterministicRiskEngine().assess(
        RiskAssessmentInput(
            weather=weather(wind_speed_knots=18, wave_height_m=2.0),
            vessel_profile=tolerant_profile,
        )
    )
    assert result.overall_score == 0
    assert result.category == "low"
