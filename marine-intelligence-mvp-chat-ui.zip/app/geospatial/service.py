"""Geometry calculations isolated from agents and language-model behavior."""

from __future__ import annotations

from math import asin, cos, radians, sin, sqrt

from shapely.geometry import Point, shape
from shapely.errors import ShapelyError

from app.domain import (
    GeoPoint,
    GeoSearchRequest,
    GeoSearchResult,
    RestrictedZone,
    ZoneSpatialAssessment,
)

EARTH_RADIUS_KM = 6371.0088
CALCULATION_VERSION = "geo-mvp-1"
GEOFENCE_CALCULATION_VERSION = "geofence-mvp-1"


class InvalidGeometryError(ValueError):
    """Raised when a stored or supplied GeoJSON geometry cannot be parsed deterministically."""


def haversine_distance_km(start: GeoPoint, end: GeoPoint) -> float:
    """Great-circle distance between two WGS84 points."""
    latitude_delta = radians(end.latitude - start.latitude)
    longitude_delta = radians(end.longitude - start.longitude)
    latitude_a = radians(start.latitude)
    latitude_b = radians(end.latitude)
    a = sin(latitude_delta / 2) ** 2 + cos(latitude_a) * cos(latitude_b) * sin(longitude_delta / 2) ** 2
    return EARTH_RADIUS_KM * 2 * asin(sqrt(a))


def geometry_centroid(geometry: dict) -> GeoPoint:
    """Return the deterministic Shapely centroid of a GeoJSON geometry."""
    center = shape(geometry).centroid
    return GeoPoint(latitude=center.y, longitude=center.x)


class GeospatialService:
    """Filters zones with declared, reproducible spatial rules."""

    def assess(self, request: GeoSearchRequest) -> GeoSearchResult:
        hazards = [shape(feature["geometry"] if "geometry" in feature else feature) for feature in request.hazard_features]
        permitted = shape(request.permitted_area) if request.permitted_area else None
        assessments: list[ZoneSpatialAssessment] = []
        for zone in request.candidate_zones:
            zone_shape = shape(zone.geometry)
            center = zone_shape.centroid
            centroid = geometry_centroid(zone.geometry)
            distance = haversine_distance_km(request.origin, centroid)
            intersects_hazard = any(zone_shape.intersects(hazard) for hazard in hazards)
            inside_permitted = permitted is None or permitted.contains(zone_shape)
            reasons: list[str] = []
            if intersects_hazard:
                reasons.append("intersects_hazard")
            if not inside_permitted:
                reasons.append("outside_permitted_area")
            if request.max_distance_km is not None and distance > request.max_distance_km:
                reasons.append("beyond_max_distance")
            assessments.append(
                ZoneSpatialAssessment(
                    zone_id=zone.zone_id,
                    centroid=centroid,
                    distance_from_origin_km=round(distance, 3),
                    intersects_hazard=intersects_hazard,
                    inside_permitted_area=inside_permitted,
                    excluded=bool(reasons),
                    exclusion_reasons=reasons,
                    route_geometry={
                        "type": "LineString", "coordinates": [[request.origin.longitude, request.origin.latitude], [center.x, center.y]]
                    },
                )
            )
        return GeoSearchResult(
            ranked_candidates=sorted(assessments, key=lambda item: (item.excluded, item.distance_from_origin_km)),
            calculation_version=CALCULATION_VERSION,
        )


def _safe_shape(geometry: dict, *, context: str):
    """Parse a GeoJSON geometry dict into a Shapely shape, or raise a clear error.

    Centralizing this here means a malformed restricted-zone polygon or an
    invalid caller-supplied geometry never reaches Shapely as an unhandled
    exception -- it always becomes a deterministic ``InvalidGeometryError``.
    """
    try:
        parsed = shape(geometry)
    except (ValueError, AttributeError, TypeError, ShapelyError) as exc:
        raise InvalidGeometryError(f"Invalid GeoJSON geometry for {context}: {exc}") from exc
    if not parsed.is_valid:
        raise InvalidGeometryError(f"Geometry for {context} is not a valid (non-self-intersecting) shape.")
    return parsed


def find_zones_containing_point(point: GeoPoint, zones: list[RestrictedZone]) -> list[RestrictedZone]:
    """Return every restricted zone whose polygon contains the point.

    A point exactly on a zone boundary is treated as inside (``covers``
    rather than ``contains``), matching a cautious, deterministic
    interpretation appropriate for a safety warning. ``point`` is a
    pydantic-validated ``GeoPoint``, so out-of-range coordinates never reach
    Shapely -- they are rejected earlier, at the domain-model boundary.
    """
    shapely_point = Point(point.longitude, point.latitude)
    matches: list[RestrictedZone] = []
    for zone in zones:
        zone_shape = _safe_shape(zone.geometry, context=f"restricted zone '{zone.zone_id}'")
        if zone_shape.covers(shapely_point):
            matches.append(zone)
    return matches


def find_zones_intersecting_geometry(geometry: dict, zones: list[RestrictedZone]) -> list[RestrictedZone]:
    """Return every restricted zone whose polygon intersects the given geometry.

    Used to check a PFZ (or any other candidate area, not just a single
    point) against restricted/protected areas: a PFZ that merely overlaps a
    restricted zone should still surface a warning, not just one fully
    contained inside it.
    """
    target_shape = _safe_shape(geometry, context="checked geometry")
    matches: list[RestrictedZone] = []
    for zone in zones:
        zone_shape = _safe_shape(zone.geometry, context=f"restricted zone '{zone.zone_id}'")
        if zone_shape.intersects(target_shape):
            matches.append(zone)
    return matches


def build_restriction_message(zone: RestrictedZone) -> str:
    """A clear, deterministic warning string for a single restricted-zone match."""
    label = zone.restriction_type.value.replace("_", " ")
    message = f"This location is inside '{zone.name}', a {label}."
    if zone.description:
        message = f"{message} {zone.description}"
    return f"{message} Entry may be restricted or prohibited -- check local maritime authority guidance before proceeding."
