"""Narrow agent contracts. Agents normalize provider facts; they do not decide risk."""

from __future__ import annotations

from typing import Generic, Protocol, TypeVar

TTask = TypeVar("TTask")
TResult = TypeVar("TResult")


class Agent(Protocol, Generic[TTask, TResult]):
    def execute(self, task: TTask) -> TResult:
        """Return structured findings for one task."""

