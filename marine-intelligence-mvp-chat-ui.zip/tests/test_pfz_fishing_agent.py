from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from app.agents.pfz_fishing import PFZFishingIntelligenceAgent
from app.domain import PFZDataRecord, PFZSearchQuery, PFZSourceMetadata
from app.services.mock.providers import DemoPFZDataProvider


class StaticPFZProvider:
    def __init__(self, records: list[PFZDataRecord]) -> None:
        self.records = records

    def get_pfz_records(self, query: PFZSearchQuery) -> list[PFZDataRecord]:
        return self.records


def test_pfz_agent_returns_timestamped_demo_records_ordered_by_distance() -> None:
    task = PFZSearchQuery(latitude=13.015, longitude=80.215)
    result = PFZFishingIntelligenceAgent(DemoPFZDataProvider()).execute(task)

    assert result.status == "success"
    assert [pfz.pfz_id for pfz in result.nearby_pfzs] == ["pfz-alpha"]
    record = result.nearby_pfzs[0]
    assert record.distance_km == pytest.approx(0)
    assert record.sea_surface_temperature_c == 28.4
    assert record.chlorophyll_mg_m3 == 0.73
    assert record.source.provider == "demo-pfz-data-service"
    assert record.observed_at.isoformat() == "2026-09-12T00:00:00+00:00"


def test_pfz_record_allows_optional_ocean_parameters_to_be_absent() -> None:
    record = PFZDataRecord(
        pfz_id="without-ocean-attributes",
        geometry={"type": "Point", "coordinates": [80.0, 13.0]},
        observed_at=datetime(2026, 9, 12, tzinfo=timezone.utc),
        source=PFZSourceMetadata(
            provider="test-provider", dataset="test-dataset", retrieved_at=datetime(2026, 9, 12, tzinfo=timezone.utc)
        ),
    )

    assert record.sea_surface_temperature_c is None
    assert record.chlorophyll_mg_m3 is None


def test_pfz_agent_orders_records_by_deterministic_distance() -> None:
    observed_at = datetime(2026, 9, 12, tzinfo=timezone.utc)
    source = PFZSourceMetadata(
        provider="test-provider", dataset="test-dataset", retrieved_at=observed_at
    )
    far = PFZDataRecord(
        pfz_id="far", geometry={"type": "Point", "coordinates": [81.0, 14.0]}, observed_at=observed_at, source=source
    )
    near = PFZDataRecord(
        pfz_id="near", geometry={"type": "Point", "coordinates": [80.01, 13.0]}, observed_at=observed_at, source=source
    )

    result = PFZFishingIntelligenceAgent(StaticPFZProvider([far, near])).execute(
        PFZSearchQuery(latitude=13.0, longitude=80.0)
    )

    assert [pfz.pfz_id for pfz in result.nearby_pfzs] == ["near", "far"]


def test_pfz_record_rejects_invalid_chlorophyll() -> None:
    with pytest.raises(ValidationError, match="chlorophyll_mg_m3"):
        PFZDataRecord(
            pfz_id="invalid",
            geometry={"type": "Point", "coordinates": [80.0, 13.0]},
            observed_at=datetime(2026, 9, 12, tzinfo=timezone.utc),
            source=PFZSourceMetadata(
                provider="test-provider", dataset="test-dataset", retrieved_at=datetime(2026, 9, 12, tzinfo=timezone.utc)
            ),
            chlorophyll_mg_m3=-0.1,
        )
