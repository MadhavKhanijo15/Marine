import pytest
from pydantic import ValidationError

from app.agents.ocean import OceanIntelligenceAgent
from app.agents.routing import RouteOptimizationAgent
from app.agents.weather import WeatherAgent
from app.domain import GeoPoint, RestrictedZone, RouteQuery, TimeWindow
from app.risk.engine import DeterministicRiskEngine
from app.services.mock.providers import (
    DemoOceanDataProvider,
    DemoPFZDataProvider,
    DemoWeatherProvider,
)

PFZ_ALPHA_CENTROID = GeoPoint(latitude=13.015, longitude=80.215)


def _window() -> TimeWindow:
    from datetime import datetime, timedelta, timezone

    now = datetime(2026, 9, 12, tzinfo=timezone.utc)
    return TimeWindow(start=now, end=now + timedelta(hours=4))


class StaticRestrictedZoneProvider:
    def __init__(self, zones: list[RestrictedZone]) -> None:
        self.zones = zones

    def get_restricted_zones(self) -> list[RestrictedZone]:
        return self.zones


def _narrow_zone() -> RestrictedZone:
    coordinates = [[80.30, 13.10], [80.32, 13.10], [80.32, 13.12], [80.30, 13.12], [80.30, 13.10]]
    return RestrictedZone(
        zone_id="narrow-mpa",
        name="Narrow Test MPA",
        restriction_type="marine_protected_area",
        geometry={"type": "Polygon", "coordinates": [coordinates]},
    )


def _wide_zone() -> RestrictedZone:
    coordinates = [[-1.0, -1.0], [11.0, -1.0], [11.0, 1.0], [-1.0, 1.0], [-1.0, -1.0]]
    return RestrictedZone(
        zone_id="wide-blocker",
        name="Wide Blocking Zone",
        restriction_type="restricted_zone",
        geometry={"type": "Polygon", "coordinates": [coordinates]},
    )


# ---- destination validation ------------------------------------------------


def test_route_query_rejects_both_destination_forms() -> None:
    with pytest.raises(ValidationError, match="exactly one"):
        RouteQuery(
            start=GeoPoint(latitude=13.0, longitude=80.0),
            destination=GeoPoint(latitude=13.1, longitude=80.1),
            destination_pfz_id="pfz-alpha",
            time_window=_window(),
        )


def test_route_query_rejects_neither_destination_form() -> None:
    with pytest.raises(ValidationError, match="exactly one"):
        RouteQuery(start=GeoPoint(latitude=13.0, longitude=80.0), time_window=_window())


def test_route_query_rejects_invalid_start_latitude() -> None:
    with pytest.raises(ValidationError, match="latitude"):
        RouteQuery(
            start=GeoPoint(latitude=95.0, longitude=80.0),
            destination=GeoPoint(latitude=13.1, longitude=80.1),
            time_window=_window(),
        )


# ---- direct / detoured / blocked routing -----------------------------------


def test_route_is_direct_when_no_restricted_zones_present() -> None:
    agent = RouteOptimizationAgent(restricted_zone_provider=StaticRestrictedZoneProvider([]))
    task = RouteQuery(
        start=GeoPoint(latitude=13.0, longitude=80.0),
        destination=GeoPoint(latitude=13.2, longitude=80.4),
        time_window=_window(),
    )
    result = agent.execute(task)

    assert result.status == "success"
    assert result.detoured is False
    assert result.clear_of_restricted_zones is True
    assert result.route == [task.start, task.destination]
    assert result.distance_km > 0
    assert result.geofence_violations == []
    assert result.risk_level is None
    assert result.risk_score is None
    assert result.warnings == []


def test_route_detours_around_a_narrow_restricted_zone() -> None:
    agent = RouteOptimizationAgent(restricted_zone_provider=StaticRestrictedZoneProvider([_narrow_zone()]))
    task = RouteQuery(
        start=GeoPoint(latitude=13.11, longitude=80.25),
        destination=GeoPoint(latitude=13.11, longitude=80.37),
        time_window=_window(),
    )
    result = agent.execute(task)

    assert result.status == "success"
    assert result.detoured is True
    assert result.clear_of_restricted_zones is True
    assert len(result.route) == 3
    assert result.geofence_violations[0].zone_id == "narrow-mpa"
    assert "restricted or prohibited" in result.geofence_violations[0].message
    assert any("rerouted around" in reason for reason in result.reasons)
    direct_km = result.distance_km
    assert direct_km > 0


def test_route_flags_zone_when_no_simple_detour_clears_it() -> None:
    agent = RouteOptimizationAgent(restricted_zone_provider=StaticRestrictedZoneProvider([_wide_zone()]))
    task = RouteQuery(
        start=GeoPoint(latitude=0.0, longitude=0.0),
        destination=GeoPoint(latitude=0.0, longitude=10.0),
        time_window=_window(),
    )
    result = agent.execute(task)

    assert result.status == "partial"
    assert result.detoured is False
    assert result.clear_of_restricted_zones is False
    assert result.route == [task.start, task.destination]
    assert result.geofence_violations[0].zone_id == "wide-blocker"
    assert any("no simple detour was clear" in warning for warning in result.warnings)


def test_route_planning_is_deterministic_across_repeated_calls() -> None:
    agent = RouteOptimizationAgent(restricted_zone_provider=StaticRestrictedZoneProvider([_narrow_zone()]))
    task = RouteQuery(
        start=GeoPoint(latitude=13.11, longitude=80.25),
        destination=GeoPoint(latitude=13.11, longitude=80.37),
        time_window=_window(),
    )
    first = agent.execute(task)
    second = agent.execute(task)

    assert first.route == second.route
    assert first.distance_km == second.distance_km
    assert first.detoured == second.detoured


# ---- PFZ destination resolution --------------------------------------------


def test_route_resolves_destination_from_existing_pfz_id() -> None:
    agent = RouteOptimizationAgent(
        restricted_zone_provider=StaticRestrictedZoneProvider([]),
        pfz_provider=DemoPFZDataProvider(),
    )
    task = RouteQuery(
        start=GeoPoint(latitude=13.0, longitude=80.0),
        destination_pfz_id="pfz-alpha",
        time_window=_window(),
    )
    result = agent.execute(task)

    assert result.status == "success"
    assert result.destination_pfz_id == "pfz-alpha"
    assert result.destination.latitude == pytest.approx(PFZ_ALPHA_CENTROID.latitude)
    assert result.destination.longitude == pytest.approx(PFZ_ALPHA_CENTROID.longitude)


def test_route_with_unknown_pfz_id_is_unavailable_and_invents_nothing() -> None:
    agent = RouteOptimizationAgent(
        restricted_zone_provider=StaticRestrictedZoneProvider([]),
        pfz_provider=DemoPFZDataProvider(),
    )
    task = RouteQuery(
        start=GeoPoint(latitude=13.0, longitude=80.0),
        destination_pfz_id="pfz-does-not-exist",
        time_window=_window(),
    )
    result = agent.execute(task)

    assert result.status == "unavailable"
    assert result.route == [task.start]
    assert result.distance_km == 0.0
    assert any("was not found" in warning for warning in result.warnings)


def test_route_without_pfz_provider_cannot_resolve_pfz_destination() -> None:
    agent = RouteOptimizationAgent(restricted_zone_provider=StaticRestrictedZoneProvider([]))
    task = RouteQuery(
        start=GeoPoint(latitude=13.0, longitude=80.0),
        destination_pfz_id="pfz-alpha",
        time_window=_window(),
    )
    result = agent.execute(task)

    assert result.status == "unavailable"
    assert any("No PFZ data available" in warning for warning in result.warnings)


# ---- risk reuse (existing data only) ---------------------------------------


def test_route_reuses_existing_weather_and_risk_data_when_supplied() -> None:
    agent = RouteOptimizationAgent(
        restricted_zone_provider=StaticRestrictedZoneProvider([]),
        weather_agent=WeatherAgent(DemoWeatherProvider()),
        ocean_agent=OceanIntelligenceAgent(DemoOceanDataProvider()),
        risk_engine=DeterministicRiskEngine(),
    )
    task = RouteQuery(
        start=GeoPoint(latitude=13.0, longitude=80.0),
        destination=GeoPoint(latitude=13.2, longitude=80.4),
        time_window=_window(),
    )
    result = agent.execute(task)

    assert result.risk_level == "low"
    assert result.risk_score == 5
    assert any("Reported sea state: slight" in reason for reason in result.reasons)


def test_route_without_risk_components_leaves_risk_unset_without_inventing_it() -> None:
    # No weather/risk agents wired: risk is simply not requested here, so
    # this must stay None (never estimated) and must not degrade the
    # otherwise-clean route's status.
    agent = RouteOptimizationAgent(restricted_zone_provider=StaticRestrictedZoneProvider([]))
    task = RouteQuery(
        start=GeoPoint(latitude=13.0, longitude=80.0),
        destination=GeoPoint(latitude=13.2, longitude=80.4),
        time_window=_window(),
    )
    result = agent.execute(task)

    assert result.risk_level is None
    assert result.risk_score is None
    assert result.status == "success"
