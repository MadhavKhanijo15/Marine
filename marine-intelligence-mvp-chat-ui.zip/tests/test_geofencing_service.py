import pytest
from pydantic import ValidationError

from app.domain import GeoPoint, RestrictedZone
from app.geospatial.service import (
    InvalidGeometryError,
    build_restriction_message,
    find_zones_containing_point,
    find_zones_intersecting_geometry,
)


def _mpa(zone_id: str = "mpa-1", coordinates: list | None = None) -> RestrictedZone:
    coordinates = coordinates or [[80.30, 13.10], [80.32, 13.10], [80.32, 13.12], [80.30, 13.12], [80.30, 13.10]]
    return RestrictedZone(
        zone_id=zone_id,
        name="Test Marine Protected Area",
        restriction_type="marine_protected_area",
        geometry={"type": "Polygon", "coordinates": [coordinates]},
        description="Seeded for tests.",
        authority="Test Authority",
    )


def test_point_inside_restricted_zone_is_detected() -> None:
    point = GeoPoint(latitude=13.11, longitude=80.31)
    matches = find_zones_containing_point(point, [_mpa()])
    assert [zone.zone_id for zone in matches] == ["mpa-1"]


def test_point_outside_restricted_zone_is_not_flagged() -> None:
    point = GeoPoint(latitude=10.0, longitude=75.0)
    matches = find_zones_containing_point(point, [_mpa()])
    assert matches == []


def test_point_on_zone_boundary_counts_as_inside() -> None:
    # Exactly on the western edge of the polygon defined in _mpa().
    point = GeoPoint(latitude=13.11, longitude=80.30)
    matches = find_zones_containing_point(point, [_mpa()])
    assert [zone.zone_id for zone in matches] == ["mpa-1"]


def test_point_check_considers_multiple_zones_independently() -> None:
    point = GeoPoint(latitude=13.11, longitude=80.31)
    other = _mpa(
        zone_id="mpa-2",
        coordinates=[[90.0, 20.0], [90.1, 20.0], [90.1, 20.1], [90.0, 20.1], [90.0, 20.0]],
    )
    matches = find_zones_containing_point(point, [_mpa(), other])
    assert [zone.zone_id for zone in matches] == ["mpa-1"]


def test_invalid_latitude_is_rejected_before_reaching_shapely() -> None:
    with pytest.raises(ValidationError, match="latitude"):
        GeoPoint(latitude=95.0, longitude=80.31)


def test_invalid_longitude_is_rejected_before_reaching_shapely() -> None:
    with pytest.raises(ValidationError, match="longitude"):
        GeoPoint(latitude=13.11, longitude=-200.0)


def test_malformed_restricted_zone_geometry_raises_invalid_geometry_error() -> None:
    point = GeoPoint(latitude=13.11, longitude=80.31)
    broken = _mpa()
    broken.geometry = {"type": "Polygon", "coordinates": [[[80.30, 13.10]]]}  # not a closed ring
    with pytest.raises(InvalidGeometryError):
        find_zones_containing_point(point, [broken])


def test_geometry_intersecting_restricted_zone_is_detected() -> None:
    pfz_geometry = {
        "type": "Polygon",
        "coordinates": [[[80.31, 13.11], [80.40, 13.11], [80.40, 13.20], [80.31, 13.20], [80.31, 13.11]]],
    }
    matches = find_zones_intersecting_geometry(pfz_geometry, [_mpa()])
    assert [zone.zone_id for zone in matches] == ["mpa-1"]


def test_geometry_outside_restricted_zone_does_not_intersect() -> None:
    pfz_geometry = {
        "type": "Polygon",
        "coordinates": [[[10.0, 5.0], [10.1, 5.0], [10.1, 5.1], [10.0, 5.1], [10.0, 5.0]]],
    }
    matches = find_zones_intersecting_geometry(pfz_geometry, [_mpa()])
    assert matches == []


def test_restriction_message_is_clear_and_names_the_zone() -> None:
    message = build_restriction_message(_mpa())
    assert "Test Marine Protected Area" in message
    assert "marine protected area" in message
    assert "restricted or prohibited" in message
