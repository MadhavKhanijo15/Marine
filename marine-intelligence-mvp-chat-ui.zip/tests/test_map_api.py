from app.main import marine_briefing


def test_marine_briefing_returns_existing_agent_data_for_the_map() -> None:
    payload = marine_briefing(latitude=13.015, longitude=80.215).model_dump(mode="json")

    assert payload["parsed_query"]["location"] == {"latitude": 13.015, "longitude": 80.215}
    assert payload["pfz"]["nearby_pfzs"]
    assert payload["weather"]["findings"]
    assert payload["ocean"]["conditions"]
    assert payload["risk"]["recommendation"] in {"go", "proceed_with_caution", "postpone", "do_not_go"}
    assert payload["evidence_recommendation"]["recommendation"] == payload["risk"]["recommendation"]


def test_marine_briefing_validates_location_before_agents_are_called() -> None:
    # FastAPI applies Query constraints at the HTTP boundary; the endpoint
    # delegates valid requests straight to existing backend agents.
    latitude_constraint = marine_briefing.__defaults__[0]
    assert any(getattr(item, "ge", None) == -90 for item in latitude_constraint.metadata)
    assert any(getattr(item, "le", None) == 90 for item in latitude_constraint.metadata)
