from app.domain import PFZAgentResult, PFZQuery
from app.services.interfaces import OceanProvider


class OceanPFZAgent:
    """Provider adapter for potential fishing-zone observations."""

    def __init__(self, provider: OceanProvider) -> None:
        self._provider = provider

    def execute(self, task: PFZQuery) -> PFZAgentResult:
        zones = self._provider.get_candidate_zones(task)
        evidence = [item for zone in zones for item in zone.evidence]
        return PFZAgentResult(status="success", candidate_zones=zones, evidence=evidence)

