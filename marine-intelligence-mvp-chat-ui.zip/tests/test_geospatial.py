from datetime import datetime, timedelta, timezone

import pytest

from app.domain import FishingZone, GeoPoint, GeoSearchRequest, TimeWindow
from app.geospatial.service import GeospatialService, haversine_distance_km


def window() -> TimeWindow:
    now = datetime(2026, 9, 12, tzinfo=timezone.utc)
    return TimeWindow(start=now, end=now + timedelta(hours=4))


def zone(zone_id: str, coordinates: list) -> FishingZone:
    return FishingZone(zone_id=zone_id, geometry={"type": "Polygon", "coordinates": [coordinates]}, validity_window=window(), suitability_score=80)


def test_haversine_distance_is_zero_for_same_point() -> None:
    point = GeoPoint(latitude=13.0, longitude=80.0)
    assert haversine_distance_km(point, point) == pytest.approx(0)


def test_geospatial_service_excludes_hazard_intersection() -> None:
    candidate = zone("unsafe", [[80, 13], [80.1, 13], [80.1, 13.1], [80, 13.1], [80, 13]])
    hazard = {"type": "Feature", "geometry": {"type": "Polygon", "coordinates": [[[80.05, 13.05], [80.15, 13.05], [80.15, 13.15], [80.05, 13.15], [80.05, 13.05]]]}}
    result = GeospatialService().assess(GeoSearchRequest(origin=GeoPoint(latitude=13, longitude=80), candidate_zones=[candidate], hazard_features=[hazard]))
    assessment = result.ranked_candidates[0]
    assert assessment.excluded is True
    assert assessment.exclusion_reasons == ["intersects_hazard"]


def test_geospatial_service_ranks_eligible_before_excluded() -> None:
    near = zone("near", [[80, 13], [80.01, 13], [80.01, 13.01], [80, 13.01], [80, 13]])
    far = zone("far", [[81, 14], [81.01, 14], [81.01, 14.01], [81, 14.01], [81, 14]])
    result = GeospatialService().assess(GeoSearchRequest(origin=GeoPoint(latitude=13, longitude=80), candidate_zones=[far, near], max_distance_km=10))
    assert [item.zone_id for item in result.ranked_candidates] == ["near", "far"]

