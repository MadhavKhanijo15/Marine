"""Natural-language parsing and specialist fan-out for marine queries."""
