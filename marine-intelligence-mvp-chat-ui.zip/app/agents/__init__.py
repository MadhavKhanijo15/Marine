"""Specialized agent interfaces and implementations."""

