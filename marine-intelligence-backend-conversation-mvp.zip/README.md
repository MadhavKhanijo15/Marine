# Marine Intelligence Assistant backend

Minimal, deterministic backend foundation for the Marine Intelligence Assistant MVP.

## Run locally

From this `backend` directory:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Check the service at `http://127.0.0.1:8000/health` and API documentation at
`http://127.0.0.1:8000/docs`.

Open `http://127.0.0.1:8000/` for the marine map MVP. It requests the
browser's location only after the user selects **Use my location**, then calls
`/api/marine-briefing`. That endpoint invokes the existing orchestrator and
returns its weather, ocean, PFZ, risk, and evidence-recommendation results.
The Leaflet client only renders those returned fields; it performs no marine
calculation, routing, geofencing, or memory.

## Follow-up conversations

`POST /api/conversations/turn` accepts a `conversation_id`, text, and optional
selected PFZ/area. It keeps only the explicit location, time window, selected
PFZ ID, and selected area for that in-process conversation. A follow-up such
as "Find a safer zone tomorrow" reuses a known location and selection while
changing only the stated time. If a location was never supplied, it remains
missing and the existing orchestrator reports unavailable location-dependent
data. Context is process-local and is not durable storage.

## Test

```powershell
pytest
```

The application deliberately exposes only health at this stage. Chat, LLM
integration, and frontend work are intentionally out of scope.

## Evidence and recommendation output

`MainOrchestratorAgent.execute()` now includes an `evidence_recommendation`
field in its `OrchestratorResult`. It is a frontend-ready, stateless view of
the already-returned agent data: the risk engine's recommendation and reasons,
observed values, provider/evidence provenance and timestamps, and explicitly
reported missing critical data. The layer never creates an operational decision
when the risk engine did not return one, and it does not add maps, routing,
geofencing, or memory.
