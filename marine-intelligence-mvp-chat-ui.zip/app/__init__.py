"""Marine Intelligence Assistant backend foundation."""

