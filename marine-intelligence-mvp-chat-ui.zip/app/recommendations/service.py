"""Transform orchestrator output into a traceable presentation model.

This module makes no operational recommendation of its own.  It only exposes
the existing risk-engine recommendation and the values/provenance already
returned by specialist agents.
"""

from __future__ import annotations

from app.domain import (
    EvidenceItem,
    EvidenceRecommendation,
    MissingCriticalData,
    OceanSourceMetadata,
    OrchestratorResult,
    RecommendationReason,
    RecommendationSource,
    RecommendationValue,
    RiskFactor,
    WeatherSourceMetadata,
)


class EvidenceRecommendationService:
    """Builds a stateless, frontend-ready view from one orchestrator result."""

    def build(self, result: OrchestratorResult) -> EvidenceRecommendation:
        sources: list[RecommendationSource] = []
        values: list[RecommendationValue] = []
        missing: list[MissingCriticalData] = []

        if result.weather:
            for finding in result.weather.findings:
                source = self._provider_source("weather", finding.source, finding.observed_at)
                sources.append(source)
                self._add_values(
                    values,
                    source,
                    {
                        "wind_speed_knots": finding.wind_speed_knots,
                        "wave_height_m": finding.wave_height_m,
                        "rainfall_mm": finding.rainfall_mm,
                        "visibility_km": finding.visibility_km,
                        "thunderstorm_probability": finding.thunderstorm_probability,
                    },
                )
                for alert in finding.alerts:
                    values.append(RecommendationValue(field="weather_alert", value=alert, source=source))
                sources.extend(self._evidence_sources(finding.evidence))
            sources.extend(self._evidence_sources(result.weather.evidence))

        if result.ocean:
            conditions = result.ocean.conditions
            source = self._provider_source("ocean", conditions.source, conditions.observed_at)
            sources.append(source)
            self._add_values(
                values,
                source,
                {
                    "sea_surface_temperature_c": conditions.sea_surface_temperature_c,
                    "chlorophyll_mg_m3": conditions.chlorophyll_mg_m3,
                    "wave_height_m": conditions.wave_height_m,
                    "wave_period_s": conditions.wave_period_s,
                    "sea_state": conditions.sea_state,
                },
            )

        for pfz in self._pfzs(result):
            source = self._provider_source("pfz", pfz.source, pfz.observed_at)
            sources.append(source)
            self._add_values(
                values,
                source,
                {
                    "pfz_id": pfz.pfz_id,
                    "distance_km": pfz.distance_km,
                    "sea_surface_temperature_c": pfz.sea_surface_temperature_c,
                    "chlorophyll_mg_m3": pfz.chlorophyll_mg_m3,
                },
            )

        reasons: list[RecommendationReason] = []
        if result.risk:
            for factor in result.risk.factors:
                if factor.contribution_points or not factor.data_available:
                    reasons.append(self._reason(factor))
                if not factor.data_available:
                    missing.append(
                        MissingCriticalData(
                            field=factor.id,
                            reason=factor.rationale,
                            reason_code=factor.reason_code,
                        )
                    )
            values.extend(self._risk_values(result.risk.factors))
        elif result.parsed_query.components.risk:
            missing.append(MissingCriticalData(field="risk_assessment"))

        # Warnings originate with the parser/orchestrator and are carried through
        # unchanged so the frontend can disclose unavailable upstream data.
        return EvidenceRecommendation(
            recommendation=result.risk.recommendation if result.risk else None,
            risk_category=result.risk.category if result.risk else None,
            overall_risk_score=result.risk.overall_score if result.risk else None,
            key_reasons=reasons,
            relevant_values=values,
            sources=sources,
            missing_critical_data=missing,
            warnings=list(result.warnings),
        )

    @staticmethod
    def _provider_source(
        source_type: str,
        metadata: WeatherSourceMetadata | OceanSourceMetadata | object,
        observed_at: object,
    ) -> RecommendationSource:
        # PFZ metadata has the same validated provenance shape as weather/ocean.
        return RecommendationSource(
            source_type=source_type,
            source_name=metadata.provider,
            provider=metadata.provider,
            dataset=metadata.dataset,
            source_url=metadata.source_url,
            observed_at=observed_at,
            retrieved_at=metadata.retrieved_at,
        )

    @staticmethod
    def _evidence_sources(evidence: list[EvidenceItem]) -> list[RecommendationSource]:
        return [
            RecommendationSource(
                source_type=item.source_type,
                source_name=item.source_name,
                observed_at=item.observed_at,
                valid_for=item.valid_for,
            )
            for item in evidence
        ]

    @staticmethod
    def _add_values(
        values: list[RecommendationValue],
        source: RecommendationSource,
        fields: dict[str, float | bool | str | None],
    ) -> None:
        values.extend(
            RecommendationValue(field=field, value=value, source=source)
            for field, value in fields.items()
            if value is not None
        )

    @staticmethod
    def _pfzs(result: OrchestratorResult):
        if result.geospatial:
            return result.geospatial.nearby_pfzs
        if result.pfz:
            return result.pfz.nearby_pfzs
        return []

    @staticmethod
    def _reason(factor: RiskFactor) -> RecommendationReason:
        return RecommendationReason(
            code=factor.reason_code,
            summary=factor.rationale,
            severity=factor.severity,
            contribution_points=factor.contribution_points,
            measured_value=factor.measured_value,
            threshold=factor.threshold,
        )

    @staticmethod
    def _risk_values(factors: list[RiskFactor]) -> list[RecommendationValue]:
        # The risk result has no provider metadata, so keep its returned values
        # visible without fabricating a source for them.
        return [
            RecommendationValue(field=factor.id, value=factor.measured_value)
            for factor in factors
            if factor.measured_value is not None
        ]
