from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from app.agents.geospatial import GeospatialAgent
from app.domain import GeospatialPFZQuery, PFZDataRecord, PFZSourceMetadata
from app.services.mock.providers import DemoPFZDataProvider


class StaticPFZProvider:
    def __init__(self, records: list[PFZDataRecord]) -> None:
        self.records = records

    def get_pfz_records(self, query: GeospatialPFZQuery) -> list[PFZDataRecord]:
        return self.records


def _record(pfz_id: str, longitude: float, latitude: float) -> PFZDataRecord:
    observed_at = datetime(2026, 9, 12, tzinfo=timezone.utc)
    source = PFZSourceMetadata(provider="test-provider", dataset="test-dataset", retrieved_at=observed_at)
    return PFZDataRecord(
        pfz_id=pfz_id,
        geometry={"type": "Point", "coordinates": [longitude, latitude]},
        observed_at=observed_at,
        source=source,
    )


def test_geospatial_query_rejects_invalid_latitude() -> None:
    with pytest.raises(ValidationError, match="latitude"):
        GeospatialPFZQuery(latitude=91, longitude=80.0, radius_km=10)


def test_geospatial_query_rejects_invalid_longitude() -> None:
    with pytest.raises(ValidationError, match="longitude"):
        GeospatialPFZQuery(latitude=13.0, longitude=181, radius_km=10)


def test_geospatial_query_rejects_non_positive_radius() -> None:
    with pytest.raises(ValidationError, match="radius_km"):
        GeospatialPFZQuery(latitude=13.0, longitude=80.0, radius_km=0)


def test_geospatial_agent_returns_demo_pfz_within_radius() -> None:
    task = GeospatialPFZQuery(latitude=13.015, longitude=80.215, radius_km=5)
    result = GeospatialAgent(DemoPFZDataProvider()).execute(task)

    assert result.status == "success"
    assert result.radius_km == 5
    assert result.origin == task.location
    assert [pfz.pfz_id for pfz in result.nearby_pfzs] == ["pfz-alpha"]
    assert result.nearby_pfzs[0].distance_km == pytest.approx(0)


def test_geospatial_agent_excludes_pfzs_beyond_radius() -> None:
    near = _record("near", longitude=80.01, latitude=13.0)
    far = _record("far", longitude=81.0, latitude=14.0)

    result = GeospatialAgent(StaticPFZProvider([far, near])).execute(
        GeospatialPFZQuery(latitude=13.0, longitude=80.0, radius_km=5)
    )

    assert [pfz.pfz_id for pfz in result.nearby_pfzs] == ["near"]


def test_geospatial_agent_orders_results_by_deterministic_distance() -> None:
    far = _record("far", longitude=80.5, latitude=13.5)
    near = _record("near", longitude=80.05, latitude=13.05)
    mid = _record("mid", longitude=80.2, latitude=13.2)

    result = GeospatialAgent(StaticPFZProvider([far, near, mid])).execute(
        GeospatialPFZQuery(latitude=13.0, longitude=80.0, radius_km=1000)
    )

    assert [pfz.pfz_id for pfz in result.nearby_pfzs] == ["near", "mid", "far"]


def test_geospatial_agent_returns_empty_list_when_nothing_in_radius() -> None:
    far = _record("far", longitude=81.0, latitude=14.0)

    result = GeospatialAgent(StaticPFZProvider([far])).execute(
        GeospatialPFZQuery(latitude=13.0, longitude=80.0, radius_km=1)
    )

    assert result.status == "success"
    assert result.nearby_pfzs == []
