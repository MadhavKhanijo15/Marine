from datetime import datetime, timedelta, timezone

from app.domain import GeoPoint, PFZQuery, TimeWindow, WeatherQuery
from app.services.mock.providers import DemoOceanProvider, DemoWeatherProvider


def test_demo_providers_return_typed_data() -> None:
    start = datetime(2026, 9, 12, tzinfo=timezone.utc)
    window = TimeWindow(start=start, end=start + timedelta(hours=3))
    point = GeoPoint(latitude=13, longitude=80)
    forecast = DemoWeatherProvider().get_forecast(WeatherQuery(location=point, time_window=window))
    zones = DemoOceanProvider().get_candidate_zones(PFZQuery(departure_point=point, time_window=window))
    assert forecast.wind_speed_knots == 12
    assert zones[0].zone_id == "pfz-alpha"
