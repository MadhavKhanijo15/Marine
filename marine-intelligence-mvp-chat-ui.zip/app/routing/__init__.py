"""Deterministic MVP route planning, isolated from agents."""
