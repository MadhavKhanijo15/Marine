"""PFZ/Fishing Intelligence Agent backed by a dedicated PFZ Data Service."""

from app.domain import NearbyPFZ, PFZFishingAgentResult, PFZSearchQuery
from app.geospatial.service import geometry_centroid, haversine_distance_km
from app.services.interfaces import PFZDataProvider


class PFZFishingIntelligenceAgent:
    """Lists PFZ observations ordered by deterministic centroid distance only."""

    def __init__(self, provider: PFZDataProvider) -> None:
        self._provider = provider

    def execute(self, task: PFZSearchQuery) -> PFZFishingAgentResult:
        nearby_pfzs = []
        for record in self._provider.get_pfz_records(task):
            coordinates = geometry_centroid(record.geometry)
            nearby_pfzs.append(
                NearbyPFZ(
                    pfz_id=record.pfz_id,
                    coordinates=coordinates,
                    distance_km=round(haversine_distance_km(task.location, coordinates), 3),
                    observed_at=record.observed_at,
                    source=record.source,
                    sea_surface_temperature_c=record.sea_surface_temperature_c,
                    chlorophyll_mg_m3=record.chlorophyll_mg_m3,
                )
            )
        return PFZFishingAgentResult(
            status="success",
            nearby_pfzs=sorted(nearby_pfzs, key=lambda item: item.distance_km),
        )

