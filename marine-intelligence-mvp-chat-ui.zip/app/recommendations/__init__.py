"""Evidence-backed, frontend-ready recommendation transformation."""

from app.recommendations.service import EvidenceRecommendationService

__all__ = ["EvidenceRecommendationService"]
