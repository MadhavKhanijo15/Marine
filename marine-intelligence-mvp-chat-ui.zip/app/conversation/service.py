"""Conservative context merge around the existing orchestrator."""

from __future__ import annotations

from threading import Lock

from app.domain import (
    ConversationContext,
    ConversationTurnRequest,
    ConversationTurnResult,
    OrchestratorQuery,
)
from app.orchestrator.agent import MainOrchestratorAgent
from app.orchestrator.parser import parse_query


class InMemoryConversationStore:
    """Thread-safe process-local store; it intentionally has no durable memory."""

    def __init__(self) -> None:
        self._contexts: dict[str, ConversationContext] = {}
        self._lock = Lock()

    def get(self, conversation_id: str) -> ConversationContext:
        with self._lock:
            return self._contexts.get(conversation_id, ConversationContext()).model_copy(deep=True)

    def save(self, conversation_id: str, context: ConversationContext) -> None:
        with self._lock:
            self._contexts[conversation_id] = context.model_copy(deep=True)


class ConversationService:
    """Resolve only explicit changes, then let existing agents perform the work."""

    def __init__(self, orchestrator: MainOrchestratorAgent, store: InMemoryConversationStore | None = None) -> None:
        self._orchestrator = orchestrator
        self._store = store or InMemoryConversationStore()

    def execute(self, turn: ConversationTurnRequest) -> ConversationTurnResult:
        existing = self._store.get(turn.conversation_id)
        parsed = parse_query(turn.text, now=turn.requested_at)
        context = existing.model_copy(
            update={
                "location": parsed.location if parsed.location is not None else existing.location,
                "time_window": parsed.time_window if parsed.time_window_explicit else existing.time_window,
                "selected_pfz_id": (
                    turn.selected_pfz_id
                    if turn.selected_pfz_id is not None
                    else parsed.selected_pfz_id or existing.selected_pfz_id
                ),
                "selected_area": turn.selected_area if turn.selected_area is not None else existing.selected_area,
            }
        )
        result = self._orchestrator.execute(
            OrchestratorQuery(text=turn.text, requested_at=turn.requested_at, context=context)
        )
        # Persist only fields already resolved by the parser, caller, or agents.
        resolved = context.model_copy(
            update={"location": result.parsed_query.location, "time_window": result.parsed_query.time_window}
        )
        result.resolved_context = resolved
        self._store.save(turn.conversation_id, resolved)
        return ConversationTurnResult(conversation_id=turn.conversation_id, context=resolved, result=result)
